
function WindowObj() {
}
WindowObj.prototype.identity = function() {
	return ('WindowObj ()');
};

WindowObj.prototype.init = function() {
  this.pulseTimer = TimerObj.alloc();
  this.pulseTimer.lifeTime = 1000;

  this.started = false;
  this.originTime = GAMEMODEL.getTime();

	this.initialPulseAdjust = 0;

  this.delay = 0;
  this.delayed = false;

  this.pulseCount = -1;

  this.totalCycleTime = 0;
  this.totalTime = 0;
  this.totalWindowCycleTime = 0;

  this.windowTimer = TimerObj.alloc();
  this.windowTimer.lifeTime = 1000;
//  this.windowWorldLeadTime = -1;

  this.windowLife = 110;
  this.windowLagRatio = 0.75;
  this.windowLead = this.windowLife * (1-this.windowLagRatio);

  this.windowCount = -1;
  this.windowPhase = -1;
  this.windowAt = -1;


/*
  this.pulseAdjust = 0;
	this.pulseStart = GAMEMODEL.getTime();
	this.pulseLife = 1000;
	this.pulseWalk = 250;
	this.pulseWindow = 110;
	this.pulseAt = -1;
	this.lgr = 0.75;

/*	this.started = false;
	this.running = false;
	this.startTime = 0;
	this.lifeTime = 3000;

	this.cycled = false;
	this.cycledBy = -1;
	this.looping = true;
  /**/
};

WindowObj.prototype.update = function() {

  var TO = GAMEMODEL.getTime();

  this.updateDelay(TO);


	if(this.started == false)	return;
	if(this.delayed == false)	return;


  var TO = GAMEMODEL.getTime();
  this.pulseTimer.update();
  this.windowTimer.update();

  var getPulseTime = this.pulseTimer.getCycle();
  var getWindowTime = this.windowTimer.getCycle();

  var pulseT = this.pulseTimer.lifeTime + getPulseTime.time;
  if(getPulseTime.cycled) {
    this.pulseCount++;
    this.totalCycleTime += this.pulseTimer.lifeTime;
  }
  if(getWindowTime.cycled) {
    this.windowCount++;
    this.totalWindowCycleTime += this.windowTimer.lifeTime;
  }
//  this.windowWorldLeadTime = (this.windowTimer.startTime) + this.totalWindowCycleTime;

  var windowT = this.windowTimer.lifeTime + getWindowTime.time;
  this.windowAt = windowT;

  if(windowT >= this.windowTimer.lifeTime) {
    this.windowPhase=0;
    this.windowAt -= this.windowTimer.lifeTime;
  }
  else if(windowT > this.windowLife) {
    this.windowPhase=-1;
  }
  else if(windowT >= this.windowLead) {
    this.windowPhase=1;
  }
  else {
    this.windowPhase=0;
  }

  console.log();

  this.totalTime = this.totalCycleTime + this.pulseTimer.lifeTime + getPulseTime.time;
//  console.log(pulseT + ' = '+this.pulseCount + ' : '+this.windowCount + ','+this.windowPhase + '  - '+windowT);

};
WindowObj.prototype.updateLeads = function() {
  var leadtime = this.windowLife * (1 - this.windowLagRatio);

  this.windowTimer.startTime = this.pulseTimer.startTime - leadtime;
  this.windowLead = leadtime;

//  console.log(this.pulseTimer.startTime +' = '+this.windowTimer.startTime + ' - '+ leadtime);
};
WindowObj.prototype.updateDelay = function(TO) {
  if(this.started && !this.delayed) {
    var dt = TO - this.originTime;
    if(dt >= this.delay) {
      this.delayed = true;
      this.pulseTimer.startTimer();
      this.windowTimer.startTimer();
			this.pulseTimer.startTime+=this.initialPulseAdjust;
			this.windowTimer.startTime+=this.initialPulseAdjust;
      this.updateLeads();
    }
  }
};
/*
WindowObj.prototype.updateNotes = function(TO) {
//  this.pulseTracker['time'] = TO;

	this.pulseTracker['walkRatio'] = (this.pulseLife/this.pulseWalk);
//	this.pulseTracker['Npulses'] = Math.ceil(this.pulseWalk/this.pulseLife);

	this.pulseTracker['pstart'] = (TO - this.pulseStart - this.pulseAdjust)%(this.pulseLife);
	this.pulseTracker['pT'] = this.pulseTracker['time'] - this.pulseTracker['pstart'];

	var walkRatio = this.pulseTracker['walkRatio'];
	var pstart = this.pulseTracker['pstart'];

	this.pulseTracker['ppos'] = (pstart/this.pulseWalk)*walkRatio;

	this.pulseTracker['windowRatio'] = (this.pulseWindow/this.pulseWalk);

	if(pstart <= this.pulseWindow) {
		this.pulseAt = pstart;
	}
	else {
		this.pulseAt = -1;
	}
};
/**/
WindowObj.prototype.startTimer = function() {
  if(this.delay == 0 || this.delayed) {
    this.delayed = true;
    this.pulseTimer.startTimer();
    this.windowTimer.startTimer();
    this.updateLeads();
  }
  if(!this.started) {
    this.originTime = GAMEMODEL.getTime();
  }
  this.started = true;
};
WindowObj.prototype.stopTimer = function() {
  this.pulseTimer.stopTimer();
  this.windowTimer.stopTimer();
};
WindowObj.prototype.getWindow = function() {
};
WindowObj.alloc = function() {
	var vc = new WindowObj();
	vc.init();
	return vc;
};
