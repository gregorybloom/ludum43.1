



function CircleActor() {
}
CircleActor.prototype = new Actor;
CircleActor.prototype.identity = function() {
	return ('CircleActor (' +this._dom.id+ ')');
};
CircleActor.prototype.init = function() {
	Actor.prototype.init.call(this);
	this.debugMode = 0;

	this.movingTo = null;
	this.nextTo = null;
	this.ptN = null;
	this.parentGrid = null;

	this.startDelay = 1;
	this.enemyType = -1;
	this.hitList = [];

	this.curBehavior = null;
	this.behaviors = {};
	this.walkList = [];

	this.size = {w:30,h:30};
	this.position = {x:0,y:0};
	this.radius = 20;
	this.maxHealthRadius = this.radius - 3;
	this.minHealthRadius = 1;
	this.curHealthRadius = this.maxHealthRadius;

	this.baseOffset = {x:0.5,y:0.35};
	this.actionMode = "MODE_STILL";

	this.maxhealth = 1;
	this.health = this.maxhealth;

	this.drawShift = {x:0,y:0};

	this.heading = {x:0,y:0};
	this.unitSpeedX = 0.21;
	this.unitSpeedY = 0.21;
	this.ticksDiff = 0;
	this.lastHeading = {x:0,y:0};

	this.focusC = (this.size.w/2)*(this.size.w/2);
	this.focusC = Math.abs(  (this.size.h/2)*(this.size.h/2)  - this.focusC  );
	this.focusC = Math.sqrt(this.focusC);

	this.dirTimeOut = 40;

	this.deathTimer = TimerObj.alloc();
	this.deathTimer.lifeTime = 1000;
	this.deathTimer.looping = false;
	this.deathRadius = (this.size.w/2 + this.size.h/2)/2;

	this.stunTimer = TimerObj.alloc();
	this.stunTimer.baseLifeTime = 520;
	this.stunTimer.lifeTime = this.stunTimer.baseLifeTime;
	this.hurtTimer = TimerObj.alloc();
	this.hurtTimer.baseLifeTime = 260;
	this.hurtTimer.lifeTime = this.hurtTimer.baseLifeTime;
	this.hurtIntensity = 0.0;

	this.switchTimer = TimerObj.alloc();
	this.switchTimer.baseLifeTime = 520;
	this.switchIntensity = 0.0;
	this.switchPosX = 0;
	this.switchPosY = 0;


	this.startPauseTimer = TimerObj.alloc();
	this.startPauseTimer.lifeTime = 1000;
	this.startPauseTimer.startTimer();
	this.startPauseTimer.first = false;


	this.moveModule = MotionModule.alloc();
	this.moveModule.target = this;

	this.updatePosition();
};
CircleActor.prototype.draw = function() {
	if(!this.alive)		return;

//	Actor.prototype.draw.call(this);
		var writeTo = 1;
		if(this.deathTimer.started) {
			if(this.deathRadius <= 0)		return;
			var prop = {fill:false, color:"#999999",width:2};
	    prop.source = "default";
	    prop.writeTo = writeTo;
		 	var shape = {type:"circle",radius:(1.5*this.deathRadius)};
	    var transf = {};
	    GAMEVIEW.drawElement(this.absPosition, shape, prop, transf);
			return;
		}


		if(this.switchTimer.running) {
			var prop = {fill:false, color:"#FF0000",width:2};
			var hi = (this.switchIntensity/20);
			var hiO = Math.min(1.0, hi+0.3);
			var hiL = Math.min(1.0, hi+0.25);
			var t = this.switchTimer.lifeTime+this.switchTimer.getCycle()['time'];
			if(t < (this.switchTimer.lifeTime/2) )			prop.color="rgba(255,220,0,"+hiO+")";
			else																				prop.color="rgba(255,220,0,"+hiL+")";
			var r = 2*t/this.switchTimer.lifeTime;
			var spos = {x:this.switchPosX,y:this.switchPosY};
			if(r < 1)	GAMEVIEW.drawCircle(spos,this.maxHealthRadius*1.4*(r+1+hi),prop.color,(hi+2));
		}



		var pos = {x:this.absPosition.x,y:this.absPosition.y};


		if(this.enemyType == 1) {
			var r = Math.random()*360;
			var h = 0;
			h = h*Math.random();
			var head = this.getHeadingFromAngle(r);
			head.x*=h;
			head.y*=h;
			head.x+=pos.x;
			head.y+=pos.y;
			var radi=this.radius-4;

			var prop = {fill:true, color:"#FF0000",width:2};
			var r = Math.random();
			prop.source = "default";
			prop.writeTo = writeTo;
			var shape = {type:"circle",radius:radi};
			var transf = {};
			GAMEVIEW.drawElement(head, shape, prop, transf);

			var prop = {fill:true, color:"#000000",width:2};
			var r = Math.random();
			prop.color = "rgba(0,0,0,"+((r/2)*0.3 +0.6)+")";
			prop.source = "default";
			prop.writeTo = writeTo;
			var shape = {type:"circle",radius:radi};
			var transf = {};
			GAMEVIEW.drawElement(head, shape, prop, transf);

		}

		var prop = {fill:false, color:"#999999",width:2};
    prop.source = "default";
    prop.writeTo = writeTo;
	 	var shape = {type:"circle",radius:this.radius};
    var transf = {};
    GAMEVIEW.drawElement(pos, shape, prop, transf);
};
CircleActor.prototype.update = function() {
	if(!this.alive)		return;
	Actor.prototype.update.call(this);
	this.deathTimer.update();
	this.startPauseTimer.update();
	this.stunTimer.update();
	this.hurtTimer.update();
	this.switchTimer.update();

	this.updateMode();

	if (this.moveModule != null)		this.moveModule.update();

	this.checkDeath();
	if(this.deathTimer.started)		this.updateDeath();
//	if(this.deathBegin)		this.updateDeath();
	this.checkEnd();
	if(this.stunTimer.running) {
		var c = this.stunTimer.getCycle();
		if(c.cycled)	this.stunTimer.stopTimer();
	}
	if(this.hurtTimer.running) {
		var c = this.hurtTimer.getCycle();
		if(c.cycled)	this.hurtTimer.stopTimer();
	}
	if(this.switchTimer.running) {
		var c = this.switchTimer.getCycle();
		if(c.cycled)	this.switchTimer.stopTimer();
	}

		var curtime = GAMEMODEL.getTime();

		if(!this.startPauseTimer.first && this.startPauseTimer.running) {
			var c = this.startPauseTimer.getCycle();
			if(c.cycled)	{
				this.startPauseTimer.first=true;
				this.startPauseTimer.stopTimer();

			}
		}


	var newPos = {x:this.position.x,y:this.position.y};
	this.updatePosition(newPos);

	this.curHealthRadius = (this.health/this.maxhealth)*(this.maxHealthRadius-this.minHealthRadius) + this.minHealthRadius;

//	if(this.animateModule != null)	this.animateModule.update();
};
CircleActor.prototype.updateMode = function() {
	if(this.parentGrid == null)		return;
	if(this.nextTo != null)				return;
	if(this.movingTo != null)			return;
	if(this.parentGrid.pulseWindow.windowPhase >= 0)		return;

	if(this.walkList.length > 0) {
		var next = this.walkList.shift();

		if(next.type == "nextTo") {
			this.nextTo = next.to;
		}
		if(next.type == "behave") {
			this.curBehavior = next.behave;
		}
		if(next.type == "done") {
			this.curBehavior = null;
		}
	}
	if(this.walkList.length == 0) {
		if(this.curBehavior == null)		return;
		if(typeof this.behaviors[this.curBehavior] === "undefined")		return;
		this.walkList = JSON.parse(JSON.stringify( this.behaviors[this.curBehavior] ));
	}

};

CircleActor.prototype.checkDeath = function() {
	if(this.debugMode==1)				return;
	if(this.deathTimer.started)	return;
	if(this.curHealthRadius < 0)		this.beginDeath();
	if(this.health < 0)			this.beginDeath();
};
CircleActor.prototype.checkEnd = function() {
	if(!this.deathTimer.started)		return;

	var cycleobj = this.deathTimer.getCycle();

//	var curtime = GAMEMODEL.getTime();
//	if(curtime > (this.deathStart+this.deathClock))	{
	if(cycleobj.cycled) {
		this.alive = false;
	}
};
CircleActor.prototype.beginDeath = function() {
	this.deathTimer.startTimer();
//	this.deathStart = GAMEMODEL.getTime();
//	this.deathBegin = true;
	if(GAMEVIEW.BoxIsInCamera(this.absBox))
	{
		var r =	0.9 + 0.3 * Math.random();
		var v = 0.45 + 0.1 * Math.random();

		this.playSound(2, v, r);
	}

};
CircleActor.prototype.updateDeath = function() {
	var curtime = GAMEMODEL.getTime();
	var deathDiff = (curtime - this.deathTimer.startTime)/this.deathTimer.lifeTime;

	this.deathRadius = 5 + 50*(deathDiff);
	if( (deathDiff) > 0.5)		this.deathRadius=0;
};


CircleActor.prototype.collide = function(act) {
	Actor.prototype.collide.call(this,act);
};
CircleActor.prototype.collideType = function(act) {
	if(act instanceof CircleActor)		return true;
	if(act instanceof CharActor)		return true;
	return false;
};
CircleActor.prototype.collideVs = function(act) {
	if(this.enemyType <= 0)			return;
	if(this.parentGrid == null)		return;

	for(var i=0; i<this.hitList.length; i++) {
		if(this.hitList[i].w < (this.parentGrid.pulseWindow.windowCount-1)) {
			this.hitList.splice(i,1);	i-=1;
		}
		else {
			if(this.hitList[i].o == act)		return;
		}
	}

	var hit=false;
	if(act instanceof CharActor)		hit = true;
	if(act instanceof CircleActor) {
		if(act.enemyType <= 0)			hit = true;
	}
	if(hit) {
		for(var i=0; i<this.hitList.length; i++) {
			if(this.hitList[i].o != act)		continue;
			if(this.parentGrid.pulseWindow.windowPhase >= 0) {
				if(this.hitList[i].w >= (this.parentGrid.pulseWindow.windowCount-1)) 	return;
			}
			else if(this.hitList[i].w != this.parentGrid.pulseWindow.windowCount)		return;
		}

		var d1 = (act.position.x - this.position.x);
		var d2 = (act.position.y - this.position.y);
		var d = d1*d1 + d2*d2;

		var r = (act.radius+this.radius);
		var tr=r*r;

		if(d <= tr) {

			// This "IF" prevents characters from moving through each other without a collision
			if(this.movingTo != act.ptN || act.movingTo != this.ptN || this.parentGrid.pulseWindow.windowPhase < 0) {
				// Collide characters only if they pass -close- to each other
				var sr = Math.sqrt(d);
				if(sr > Math.max(act.radius,this.radius))		return;
			}


			act.damage(8.0,1.0,'hurt');

			var hitobj = {};
			hitobj.w = this.parentGrid.pulseWindow.windowCount;
			hitobj.o = act;
			this.hitList.push(hitobj);

		}

/*		var interBox = GAMEGEOM.BoxIntersection(this.absBox, act.absBox);
		var interCenter = {x:0,y:0};
		interCenter.x = interBox.x + interBox.w/2;
		interCenter.y = interBox.y + interBox.h/2;

		var actCenter = {x:0,y:0};
		actCenter.x = act.absBox.x + act.absBox.w/2;
		actCenter.y = act.absBox.y + act.absBox.h/2;		/**/
	}	/**/
};



CircleActor.prototype.damage = function(dmg,stun,type,ints=1.0) {
	this.stunTimer.lifeTime = this.stunTimer.baseLifeTime * stun;
	this.stunTimer.startTimer();

	if(type == 'hurt') {
		this.health-=dmg;
		this.hurtTimer.lifeTime = this.hurtTimer.baseLifeTime * stun;
		this.hurtTimer.startTimer();
		this.hurtIntensity=dmg*ints;
	}
};
CircleActor.prototype.heal = function(heal,stun,type,ints=1.0) {
//	this.healFlashTimer.lifeTime = this.healFlashTimer.baseLifeTime * stun;
//	this.healFlashTimer.startTimer();

//	if(type == 'heal') {
		this.health+=heal;
		if(this.health > this.maxhealth)	this.health = this.maxhealth;
		this.healTimer.lifeTime = this.healTimer.baseLifeTime * stun;
		this.healTimer.startTimer();
		this.healIntensity=heal*ints;
//	}
};
CircleActor.prototype.hitSwitch = function(type,posX,posY,ints=1.0) {
//	this.healFlashTimer.lifeTime = this.healFlashTimer.baseLifeTime * stun;
//	this.healFlashTimer.startTimer();

		this.switchTimer.lifeTime = this.switchTimer.baseLifeTime;
		this.switchTimer.startTimer();
		this.switchIntensity=ints;
		this.switchPosX=posX;
		this.switchPosY=posY;
};


CircleActor.alloc = function() {
	var vc = new CircleActor();
	vc.init();
	return vc;
};
