function WireGrid()
{
}

WireGrid.prototype = new Actor;

WireGrid.prototype.identity = function()
{
	return ('WireGrid (' + this._dom.id + ')');
};

WireGrid.prototype.init = function()
{
	Actor.prototype.init.call(this);

	this.points = {};

	this.connections = [];
	this.changes = {};

	this.objectLists = {};
	this.nodeData = {};

	this.pulseStart = GAMEMODEL.getTime();
	this.pulseLife = 1000;
	this.pulseWalk = 250;
	this.pulseWindow = 110;
	this.pulseAt = -1;
	this.lgr = 0.75;

	this.pressWindow = 260;
	this.prlgr=0.28;
	this.windowNum=-1;
	this.windowPhase=-1;
	this.pressFrames={};

	this.pulseTracker = {};
	this.pressTracker = {};


	this.impactTimer = TimerObj.alloc();
	this.impactTimer.lifeTime = 1000;

};
WireGrid.prototype.loadingData = function(data)
{
	Actor.prototype.loadingData.call(this,data);
};
WireGrid.prototype.addObject = function(type,obj,n)
{
	var char = {obj:null,ptn:null,move:false,movep:0,start:null,movingTo:null};

	if(type == 'char') {
		if(typeof this.objectLists['char'] === "undefined" ||
			this.objectLists['char'].length > 0) {
				this.objectLists['char']=[];
		}
	}

	char.obj = obj;
	char.ptn = n;
	char.start = GAMEMODEL.getTime();
	this.objectLists[type].push(char);

	this.updateObjs();
};
WireGrid.prototype.addPoint = function(name,pt,data,link)
{
	if(typeof pt !== "undefined" && pt != null) {
		this.points[name]={x:pt.x,y:pt.y,data:data};
	}
	if(typeof link !== "undefined" && link != null) {
		this.addLink(link);
	}
};
WireGrid.prototype.addLink = function(link,outward=true)
{
	if(typeof link['pts'] === "undefined")	return;
	var from = link['pts'][0];

	var wiregroup = 'outWires';
	if(outward == false)		wiregroup = 'inWires';

	if(typeof this.nodeData[from] === "undefined")							this.nodeData[from]={};
	if(typeof this.nodeData[from][wiregroup] === "undefined")	this.nodeData[from][wiregroup]=[];

	for(var j=1;j<link['pts'].length;j++) {
		var outwire = {'to':link['pts'][j]};
		for(var a in this.nodeData[from][wiregroup]) {
			if(this.nodeData[from][wiregroup]['to']==outwire['to']) {continue;}
		}

		var revwire = {};
		for(var item in link) {
			if(item == 'pts')	continue;
			outwire[item]=link[item];
			revwire[item]=link[item];
		}
		console.log(outwire);
		this.nodeData[from][wiregroup].push(outwire);

		if(outward == false)	continue;
		revwire['pts']=[];
		revwire['pts'].push(link['pts'][j]);
		revwire['pts'].push(link['pts'][0]);
//		this.addLink(revwire,false);
	}

	if(outward == false)	return;
	this.connections.push(link);
};
WireGrid.prototype.draw = function()
{
	var lightUp = function(grid,i,prop,shape) {
		var TO = grid.pulseTracker['time'];

		var lights = false;

		for(var n=0; n<grid.pulseTracker['Npulses']; n++) {
			var nodepos = (n*grid.pulseLife)*grid.pulseTracker['walkRatio']/grid.pulseWalk + grid.pulseTracker['ppos'];
			var phead = nodepos + grid.pulseTracker['windowRatio']*(1-grid.lgr);
			var ptail = nodepos - grid.pulseTracker['windowRatio']*(grid.lgr);

			if (ptail <= 0.0)	lights=true;
			if (phead >= 1.0)	lights=true;
			if(lights)	break;
		}
		if(lights) {
			var ptx = grid.absPosition.x + grid.points[i].x;
			var pty = grid.absPosition.y + grid.points[i].y;
			GAMEVIEW.drawElement({x:ptx,y:pty}, shape, prop, {});
		}
	};
	var drawPulse = function(grid,ptx,pty,i,j,prop,shape) {
		var TO = grid.pulseTracker['time'];	//GAMEMODEL.getTime();

		for(var n=0; n<grid.pulseTracker['Npulses']; n++) {
			var nodepos = (n*grid.pulseLife)*grid.pulseTracker['walkRatio']/grid.pulseWalk + grid.pulseTracker['ppos'];
			var phead = nodepos + grid.pulseTracker['windowRatio']*(1-grid.lgr);
			var ptail = nodepos - grid.pulseTracker['windowRatio']*(grid.lgr);

			if (phead < 0)	phead=0;
			if (ptail < 0)	ptail=0;
			if (phead > 1)	phead=1;
			if (ptail > 1)	ptail=1;

			var pdiffx = (ptx[j] - ptx[0]);
			var pdiffy = (pty[j] - pty[0]);
			var ptHx = phead * pdiffx + ptx[0];
			var ptHy = phead * pdiffy + pty[0];
			var ptTx = ptail * pdiffx + ptx[0];
			var ptTy = ptail * pdiffy + pty[0];

			prop.color = "#000099";
			shape.pts = [];
			shape.pts.push({x:ptHx,y:ptHy,t:'m'});
			shape.pts.push({x:ptTx,y:ptTy,t:'l'});

			GAMEVIEW.drawElement(grid.position, shape, prop, {});
		};


	}


	this.updatePulse();
	this.updatePress();

	for(var i in this.connections) {
		var ptx = [];
		var pty = [];
		var pnamelist = [];
		for(var j in this.connections[i].pts) {
			var pname = this.connections[i].pts[j];
			var pt1x = this.points[pname].x;
			var pt1y = this.points[pname].y;
			ptx.push(pt1x);
			pty.push(pt1y);
			pnamelist.push(j);
//			console.log(pname);
		}
//		console.log(ptx);

		for(var j=1; j<(ptx.length); j++)
		{
			var prop = {fill:false, color:"#999999", width:2};
			prop.source = "default";
			prop.writeTo = 0;

			var shape = {type:"shape",pts:[],pt:this.position};
			shape.pts.push({x:ptx['0'],y:pty['0'],t:'m'});
			shape.pts.push({x:ptx[j],y:pty[j],t:'l'});

			GAMEVIEW.drawElement(this.position, shape, prop, {});

			// Draw direction indicator
			var pt2x = ptx[j]-ptx['0'];
			var pt2y = pty[j]-pty['0'];
			var D2 = Math.sqrt(pt2x*pt2x + pt2y*pt2y) * 0.045;
			if (D2 < 4)	D2=4;
			pt2x = pt2x/D2 + ptx['0'];
			pt2y = pt2y/D2 + pty['0'];

			var shape = {type:"shape",pts:[],pt:this.position};
			shape.pts.push({x:ptx['0'],y:pty['0'],t:'m'});
			shape.pts.push({x:pt2x,y:pt2y,t:'l'});
			prop.width=3;
			var d = this.getDestinationAt( this.connections[i].pts[0] );
			prop.color="#FF0000";

			var cdestname = this.connections[i].pts[ pnamelist[j] ];
			if(cdestname != d)			prop.color="#0000FF";
			GAMEVIEW.drawElement(this.position, shape, prop, {});


			drawPulse(this,ptx,pty,i,j,prop,shape);
		}
	}
	for(var i in this.points) {
		var ptx = this.absPosition.x + this.points[i].x;
		var pty = this.absPosition.y + this.points[i].y;
		//	GAMEVIEW.fillCircle(this.absPosition,this.radius,"#000066");
		GAMEVIEW.fillCircle({x:ptx,y:pty},5,"#666666",1);

		var prop = {fill:false, color:"#66000", width:2};
		prop.source = "default";
		prop.writeTo = 0;
		var shape = {type:"circle",pt:this.position,radius:5};
		lightUp(this,i,prop,shape);

		if(this.pressTracker['pressable'] == true) {
			GAMEVIEW.drawCircle({x:ptx,y:pty},9,"#FF00FF",1);
		}
	}
};

WireGrid.prototype.update = function()
{
	Actor.prototype.update.call(this);
//	this.accel.update();

//	this.updateMode();
//	this.impactTimer.update();

	this.updatePulse();
	this.updatePress();
	this.updateHits();
	this.updateObjs();
};
WireGrid.prototype.addPressFrame = function(key,char,time) {
	if(this.windowNum == 0)		return;
	if(typeof char.keyPressList[key] === "undefined")		return;
	if(typeof this.pressFrames[this.windowNum] === "undefined")
	{
		this.pressFrames[this.windowNum]=[];
	}
	for(var i in this.pressFrames[this.windowNum]) {
		var frame = this.pressFrames[this.windowNum][i];
//		if(frame.key == key && frame.time == time)		return;
		if(frame.key == key && frame.time == char.keyPressList[key])		return;
	}
	var newframe = {};
	newframe['key'] = key;
	newframe['time'] = char.keyPressList[key];
	newframe['frame'] = this.windowNum;
	newframe['phase'] = this.windowPhase;
	newframe['new'] = true;
	newframe['miss'] = false;
	if(this.windowPhase < 0)	newframe['miss'] = true;

	this.pressFrames[this.windowNum].push(newframe);
	console.log(newframe);
};
WireGrid.prototype.updateHits = function()
{
	if(typeof this.objectLists['char'] === "undefined" ||
		this.objectLists['char'].length > 0) {
			var charset = this.objectLists['char'][0];
			var char = charset.obj;
	}
	else {
		return;
	}

	this.updateFrames();

	for(var a in this.pressFrames) {
		var framegroup = this.pressFrames[a];
		for(var b in framegroup) {
			var frame = framegroup[b];

			if(frame['new'] == false)							continue;
			if(frame['frame'] != this.windowNum)	continue;

			if(frame['miss'] == true || frame['phase'] < 0) {

			}
			else {
				for(var a in this.connections) {
					if(this.connections[a].pts[0] == charset.ptn) {
						if(this.connections[a].pts.length > 2) {
							if(typeof this.changes[a] === "undefined")	this.changes[a] = {};

							var pname = this.connections[a].pts[2];
							this.changes[a]['dest'] = pname;
//							console.log('hit at '+a+', '+JSON.stringify(frame));
							if(this.pulseAt >= 0) {
								charset['movingTo'] = pname;
							}
							break;
						}
					}
				}

			}
			frame['new']= false;

		}
	}

};
WireGrid.prototype.updateFrames = function() {
	if(typeof this.objectLists['char'] === "undefined" ||
		this.objectLists['char'].length > 0) {
			var charset = this.objectLists['char'][0];
			var char = charset.obj;

			if(this.pressTracker['pressable'] == true) {

				for(var i in char.keyList) {
					var keyname = char.keyList[i];
					if(typeof char.keyPressList[keyname] !== "undefined")
					{
						var time = char.keyPressList[keyname];
						if(time >= this.pressTracker['pheadT']) {
							if(time <= this.pressTracker['ptailT']) {
								this.addPressFrame(keyname,char,time);
							}
						}
					}
				}
			}
		}
		for(var i in this.pressFrames) {
			var framegroup = this.pressFrames[i];

			if(i < (this.windowNum-10)) {
				delete this.pressFrames[i];
			}
		}
};
WireGrid.prototype.getConnectionsAt = function(ptn) {
	var list = [];
	for(var a in this.connections) {
		if(this.connections[a].pts[0] == ptn)		list.push(a);
	}
	return list;
};
WireGrid.prototype.getDestinationAt = function(ptn) {
	var list = this.getConnectionsAt(ptn);
	for(var a in list) {
		var cname = list[a];
		if(typeof this.connections[cname] !== "undefined") {
			var tdest = this.connections[cname].pts[1];

			var pname = this.connections[cname].pts[0];
			if(typeof this.changes[pname] !== "undefined") {
				tdest = this.changes[pname]['dest'];
			}
			return tdest;
		}
	}
};

WireGrid.prototype.updateObjs = function()
{
	var objStepping = function(grid,objset) {
		if(grid.pulseAt < 0)		return false;
		if(objNotFirst(grid,objset)==false)		return false;
		for(var i in grid.connections) {
			if(grid.connections[i].pts[0] == objset.ptn)		return true;
		}
		return false;
	};
	var objNotFirst = function(grid,objset) {
		var ptime = grid.pulseTracker['time'] - grid.pulseTracker['pstart'];
		var n = 0;
		if(ptime <= (objset.start+n*this.pulseLife))		return false;
		return true;
	};

	for(var name in this.objectLists) {
		for(var item in this.objectLists[name]) {
			var objset = this.objectLists[name][item];

			if(this.pulseAt < 0 && objset['movingTo'] != null) {
				objset['ptn']=objset['movingTo'];
				objset['movingTo']=null;
			}

			var n = objset['ptn'];
			if(typeof this.points[n] !== "undefined") {
				var ptAx = this.absPosition.x + this.points[n].x;
				var ptAy = this.absPosition.y + this.points[n].y;

				if(objStepping(this,objset) == false) {
					objset['obj'].updatePosition({x:ptAx,y:ptAy});
				}
				else {
					if(objset['movingTo'] == null) {
						for(var i in this.connections) {
							if(this.connections[i].pts[0] == objset.ptn) {
//								var pname = this.connections[i].pts[1];
								var pname = this.getDestinationAt( this.connections[i].pts[0] );
								objset['movingTo'] = pname;
								break;
							}
						}
					}

					if(objset['movingTo'] != null) {
						var pname = objset['movingTo'];
						var pt1x = this.points[pname].x;
						var pt1y = this.points[pname].y;
						wratio = this.pulseAt / this.pulseWalk;
						var ptx = wratio*(pt1x-this.points[n].x)+ptAx;
						var pty = wratio*(pt1y-this.points[n].y)+ptAy;

						objset['obj'].updatePosition({x:ptx,y:pty});
					}
				}
			}

		}
	}

};
WireGrid.prototype.updatePulse = function()
{
	var TO = GAMEMODEL.getTime();

	this.pulseTracker['time'] = TO;

	this.pulseTracker['walkRatio'] = (this.pulseLife/this.pulseWalk);
	this.pulseTracker['Npulses'] = Math.ceil(this.pulseWalk/this.pulseLife);

	this.pulseTracker['pstart'] = (TO - this.pulseStart)%(this.pulseLife);
	this.pulseTracker['pT'] = this.pulseTracker['time'] - this.pulseTracker['pstart'];

	var walkRatio = this.pulseTracker['walkRatio'];
	var pstart = this.pulseTracker['pstart'];

	this.pulseTracker['ppos'] = (pstart/this.pulseWalk)*walkRatio;

	this.pulseTracker['windowRatio'] = (this.pulseWindow/this.pulseWalk);

	if(pstart <= this.pulseWindow) {
		this.pulseAt = pstart;
	}
	else {
		this.pulseAt = -1;
	}
};
WireGrid.prototype.updatePress = function()
{
	this.pressTracker['time'] = this.pulseTracker['time'];
	this.pressTracker['pdiff'] = this.pulseTracker['pstart'];
	this.pressTracker['windowRatio'] = (this.pressWindow/this.pulseWalk);

	var phead = this.pressTracker['pdiff'] + this.pulseWalk*this.pressTracker['windowRatio']*(1-this.prlgr);
	var ptail = this.pressTracker['pdiff'] - this.pulseWalk*this.pressTracker['windowRatio']*(this.prlgr);
//	phead /= this.pulseLife;
//	ptail /= this.pulseLife;

	this.pressTracker['phead'] = phead;
	this.pressTracker['ptail'] = ptail;

	this.pressTracker['pregion'] = -1;
	if(phead >= this.pulseLife)		this.pressTracker['pregion'] = phead-this.pulseLife;
	else if(ptail <= 0)						this.pressTracker['pregion'] = phead;

	this.pressTracker['pressable']=false;
	if(this.pressTracker['pregion'] >= 0)
	{
		this.pressTracker['pressable']=true;
		this.pressTracker['pheadT'] = this.pressTracker['time'] - this.pressTracker['pregion'];
	}
	else {
		this.pressTracker['pheadT'] = this.pressTracker['time'] - phead;
	}
	this.pressTracker['ptailT'] = this.pressTracker['pheadT'] + this.pressWindow;

	if(this.pressTracker['time'] <= this.pressTracker['ptailT'] && this.pressTracker['time'] >= this.pressTracker['pheadT']) {
		if(this.windowPhase < 0) {
			this.windowNum++;
		}
		this.windowPhase=0;
		if(this.pulseTracker['pT'] >= this.pressTracker['pheadT'])	this.windowPhase=1;
	}
	else {
		this.windowPhase=-1;
	}
};
WireGrid.prototype.updateMode = function()
{

	var curtime = GAMEMODEL.getTime();
	if(	this.accelMode == "MODE_IMPACT") {
		var c = this.impactTimer.getCycle();
//		console.log(this.accel.curVelX + ' f ' + this.accel.curVelY);
		if(this.impactTimer.started && this.impactTimer.running) {
			if(c.cycled) {
				this.accelMode = "MODE_LOOKING";
				this.impactTimer.stopTimer();
			}
		}
	}
};

WireGrid.prototype.collide = function(act) {
	Actor.prototype.collide.call(this,act);
};
WireGrid.prototype.collideType = function(act) {
	return false;
};
WireGrid.prototype.collideVs = function(act) {
};


WireGrid.alloc = function()
{
	var vc = new WireGrid();
	vc.init();
	return vc;
};
