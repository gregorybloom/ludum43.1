



function CharActor() {
}
CharActor.prototype = new Actor;
CharActor.prototype.identity = function() {
	return ('CharActor (' +this._dom.id+ ')');
};
CharActor.prototype.init = function() {
	Actor.prototype.init.call(this);
	this.debugMode = 0;
	this.exit = false;

	this.startDelay = 1;

	this.movingTo = null;
	this.nextTo = null;
	this.ptN = null;

	this.parentGrids = {};
	this.controlLinks = {};

	this.size = {w:30,h:30};
	this.position = {x:0,y:0};
	this.radius = 15;
	this.maxHealthRadius = this.radius - 3;
	this.minHealthRadius = 1;
	this.curHealthRadius = this.maxHealthRadius;

	this.baseOffset = {x:0.5,y:0.35};
	this.actionMode = "MODE_STILL";

	this.maxhealth = 20;
	this.health = this.maxhealth;

	this.drawShift = {x:0,y:0};

	this.heading = {x:0,y:0};
	this.unitSpeedX = 0.21;
	this.unitSpeedY = 0.21;
	this.ticksDiff = 0;
	this.lastHeading = {x:0,y:0};

	this.focusC = (this.size.w/2)*(this.size.w/2);
	this.focusC = Math.abs(  (this.size.h/2)*(this.size.h/2)  - this.focusC  );
	this.focusC = Math.sqrt(this.focusC);

	this.dirTimeOut = 40;

	this.deathTimer = TimerObj.alloc();
	this.deathTimer.lifeTime = 1000;
	this.deathTimer.looping = false;
	this.deathRadius = (this.size.w/2 + this.size.h/2)/2;

	this.exitTimer = TimerObj.alloc();
	this.exitTimer.lifeTime = 1000;

	this.stunTimer = TimerObj.alloc();
	this.stunTimer.baseLifeTime = 520;
	this.stunTimer.lifeTime = this.stunTimer.baseLifeTime;
	this.hurtTimer = TimerObj.alloc();
	this.hurtTimer.baseLifeTime = 260;
	this.hurtTimer.lifeTime = this.hurtTimer.baseLifeTime;
	this.hurtIntensity = 0.0;

	this.healTimer = TimerObj.alloc();
	this.healTimer.baseLifeTime = 520;
	this.healIntensity = 0.0;

	this.switchTimer = TimerObj.alloc();
	this.switchTimer.baseLifeTime = 520;
	this.switchIntensity = 0.0;
	this.switchPosX = 0;
	this.switchPosY = 0;

	this.startPauseTimer = TimerObj.alloc();
	this.startPauseTimer.lifeTime = 1000;
	this.startPauseTimer.startTimer();
	this.startPauseTimer.first = false;

	this.keyList = ["UA","DA","LA","RA","SP"];
	this.keyTimeList = {};
	this.keyStateList = {};
	this.keyPressList = {};
	this.newPressList = {};
	for(var i=0; i<this.keyList.length; i++) {
		var keyname = this.keyList[i];
		this.keyTimeList[keyname] = GAMEMODEL.getTime();
		this.keyPressList[keyname] = -1;
		this.keyStateList[keyname] = false;
		this.newPressList[keyname] = false;
	}

	this.moveModule = MotionModule.alloc();
	this.moveModule.target = this;


	this.updatePosition();
};
CharActor.prototype.draw = function() {

//	Actor.prototype.draw.call(this);
		var writeTo = 1;
		if(this.deathTimer.started) {
			if(this.deathRadius <= 0)		return;
			var prop = {fill:false, color:"#0099FF",width:2};
	    prop.source = "default";
	    prop.writeTo = writeTo;
		 	var shape = {type:"circle",radius:(1.5*this.deathRadius)};
	    var transf = {};
	    GAMEVIEW.drawElement(this.absPosition, shape, prop, transf);
			return;
		}

/*		var eyept = {x:0,y:0};
		eyept.x = this.lastHeading.x * this.radius;
		eyept.y = this.lastHeading.y * this.radius;
		if(eyept.x != 0 && eyept.y != 0) {
			eyept.x *= 0.76;
			eyept.y *= 0.76;
		}
		if(eyept.x != 0 || eyept.y != 0) {
			eyept.x += this.absPosition.x;
			eyept.y += this.absPosition.y;

			var prop = {fill:true, color:"#666666",width:1};
			prop.source = "default";
			prop.writeTo = 1;
			var shape = {type:"circle",radius:5};
			var transf = {};
			GAMEVIEW.drawElement(eyept, shape, prop, transf);
		}
/**/
		var pos = {x:this.absPosition.x,y:this.absPosition.y};
		if(this.stunTimer.running || this.hurtTimer.running) {
			var r = Math.random()*360;
			var h = Math.random();

			if(this.hurtTimer.running) {
				var t = this.hurtTimer.lifeTime+this.hurtTimer.getCycle()['time'];
				var hi = this.hurtIntensity -1;
				if(t < (this.hurtTimer.lifeTime/2) )			h*=6+hi;
				else if(t < (this.hurtTimer.lifeTime/3) )	h*=3+hi/2;
				else																			h*=1.5+hi/4;
			}
			else if(this.stunTimer.running) {
				var t = this.stunTimer.lifeTime+this.stunTimer.getCycle()['time'];
				if(t < (this.stunTimer.lifeTime/5) )			h=h*1.1;
				else if(t < (this.stunTimer.lifeTime/2) )	h=h*1.05;
				else																			h=h*1.0;
			}

			var head = this.getHeadingFromAngle(r);
			head.x*=h;
			head.y*=h;
			pos.x+=head.x;
			pos.y+=head.y;
		}

		var prop = {fill:false, color:"#0099FF",width:2};
    prop.source = "default";
    prop.writeTo = writeTo;
	 	var shape = {type:"circle",radius:this.radius};
    var transf = {};
		if(this.exitTimer.running) {
			var t= (this.exitTimer.lifeTime + this.exitTimer.getCycle()['time'])/this.exitTimer.lifeTime;
			prop.color = "rgba(00,153,255,"+(1-t)+")";
		}
    GAMEVIEW.drawElement(pos, shape, prop, transf);


		var shape = {type:"circle",radius:(this.curHealthRadius+2)};
		var prop = {fill:true, color:"rgba(00,113,197,0.35)",width:1};
		if(this.exitTimer.running) {
			var t= (this.exitTimer.lifeTime + this.exitTimer.getCycle()['time'])/this.exitTimer.lifeTime;
			prop.color = "rgba(00,113,197,"+(0.35*(1-t))+")";
		}
		if(this.hurtTimer.running) {
			var hi = (this.hurtIntensity/20);
			var hiO = Math.min(1.0, hi+0.4);
			var hiL = Math.min(1.0, hi+0.35);
			var t = this.hurtTimer.lifeTime+this.hurtTimer.getCycle()['time'];
			if(t < (this.hurtTimer.lifeTime/2) )			prop.color="rgba(220,0,50,"+hiO+")";
			else																			prop.color="rgba(170,90,70,"+hiL+")";
			shape.radius = Math.max(this.maxHealthRadius,(this.curHealthRadius+2));
		}
		else if(this.stunTimer.running) {
			var t = this.stunTimer.lifeTime+this.stunTimer.getCycle()['time'];
			if(t < (this.stunTimer.lifeTime/2) )			prop.color="rgba(70,90,70,0.35)";
			else																			prop.color="rgba(100,120,100,0.35)";
			shape.radius = Math.max((this.maxHealthRadius*0.5),(this.curHealthRadius+2));
		}
		else if(this.healTimer.running) {
			var hi = (this.healIntensity/40);
			var hiO = Math.min(1.0, hi+0.3);
			var hiL = Math.min(1.0, hi+0.25);
			var t = this.healTimer.lifeTime+this.healTimer.getCycle()['time'];
			if(t < (this.healTimer.lifeTime/2) )			prop.color="rgba(0,180,255,"+hiO+")";
			else																			prop.color="rgba(0,110,220,"+hiL+")";
			var r = 2*t/this.healTimer.lifeTime;
			if(r < 1)	GAMEVIEW.drawCircle(pos,this.maxHealthRadius*(r+1+hi),prop.color,(hi+2));
		}
		else if(this.switchTimer.running) {
			var hi = (this.switchIntensity/20);
			var hiO = Math.min(1.0, hi+0.3);
			var hiL = Math.min(1.0, hi+0.25);
			var t = this.switchTimer.lifeTime+this.switchTimer.getCycle()['time'];
			if(t < (this.switchTimer.lifeTime/2) )			prop.color="rgba(255,220,0,"+hiO+")";
			else																			prop.color="rgba(255,220,0,"+hiL+")";
			var r = 2*t/this.switchTimer.lifeTime;
			var spos = {x:this.switchPosX,y:this.switchPosY};
			if(r < 1)	GAMEVIEW.drawCircle(spos,this.maxHealthRadius*1.4*(r+1+hi),prop.color,(hi+2));
		}
		GAMEVIEW.drawElement(pos, shape, prop, transf);

/*
		var prop = {fill:true, color:"rgba(84, 197,113,0.5)",width:1};
		GAMEVIEW.drawElement(this.absPosition, shape, prop, transf);
		if(this.curHealthRadius <= 0)		return;
		var shape = {type:"circle",radius:(this.curHealthRadius)};
		var prop = {fill:false, color:"#54C571",width:1};
		GAMEVIEW.drawElement(this.absPosition, shape, prop, transf);
/**/
/*
		var prop = {fill:false, color:'#FF00FF', width:2};
		prop.source = "default";
		prop.writeTo = 2;
//		var shape = {type:"line",pt1:{x:0,y:0},pt2:{x:0,y:10}};
		var transf = {};

		var pts = [];
		var pt1 = {x:0,y:0};
		var pt2 = {x:0,y:0};
		if(headx < 0)		pt2.x = -15;
		if(headx > 0)		pt2.x = 15;
		if(heady < 0)		pt2.y = -15;
		if(heady > 0)		pt2.y = 15;
		pts.push({x:pt1.x,y:pt1.y,t:'m'});
		pts.push({x:pt2.x,y:pt2.y,t:'l'});

		var shape = {type:"shape",pt:{x:0,y:0}};
		shape.pts = pts;
		GAMEVIEW.drawElement(this.absPosition, shape, prop, transf);
/**/


};
CharActor.prototype.update = function() {
	Actor.prototype.update.call(this);
	this.deathTimer.update();
	this.startPauseTimer.update();
	this.exitTimer.update();
	this.stunTimer.update();
	this.hurtTimer.update();
	this.healTimer.update();
	this.switchTimer.update();



	if (this.moveModule != null)		this.moveModule.update();

	this.checkDeath();
	if(this.deathTimer.started)		this.updateDeath();
//	if(this.deathBegin)		this.updateDeath();
	this.checkEnd();
	if(this.exitTimer.running) {
		var c = this.exitTimer.getCycle();
		if(c.cycled)	{
			this.exit=true;
		}
	}
	if(this.stunTimer.running) {
		var c = this.stunTimer.getCycle();
		if(c.cycled)	this.stunTimer.stopTimer();
	}
	if(this.hurtTimer.running) {
		var c = this.hurtTimer.getCycle();
		if(c.cycled)	this.hurtTimer.stopTimer();
	}
	if(this.healTimer.running) {
		var c = this.healTimer.getCycle();
		if(c.cycled)	this.healTimer.stopTimer();
	}
	if(this.switchTimer.running) {
		var c = this.switchTimer.getCycle();
		if(c.cycled)	this.switchTimer.stopTimer();
	}

		var curtime = GAMEMODEL.getTime();

		if(!this.startPauseTimer.first && this.startPauseTimer.running) {
			var c = this.startPauseTimer.getCycle();
			if(c.cycled)	{
				this.startPauseTimer.first=true;
				this.startPauseTimer.stopTimer();
			}
		}

	this.updateCurrentMode();
	this.updateCurrentAnimation();

	var newPos = {x:this.position.x,y:this.position.y};

	this.updatePosition(newPos);

	this.curHealthRadius = (this.health/this.maxhealth)*(this.maxHealthRadius-this.minHealthRadius) + this.minHealthRadius;

//	if(this.animateModule != null)	this.animateModule.update();
};
CharActor.prototype.updateCurrentMode = function() {

	var keyids = GAMECONTROL.keyIDs;
	var R = (GAMECONTROL.getKeyState(keyids['KEY_ARROW_RIGHT']) || GAMECONTROL.getKeyState(keyids['KEY_D']));
	var L = (GAMECONTROL.getKeyState(keyids['KEY_ARROW_LEFT']) || GAMECONTROL.getKeyState(keyids['KEY_A']));
	var U = (GAMECONTROL.getKeyState(keyids['KEY_ARROW_UP']) || GAMECONTROL.getKeyState(keyids['KEY_W']));
	var D = (GAMECONTROL.getKeyState(keyids['KEY_ARROW_DOWN']) || GAMECONTROL.getKeyState(keyids['KEY_S']));

	if(this.deathTimer.started)					return;

	if( !D && !U )					this.heading.y = 0;
	else if ( D && U ) {
		if( this.keyTimeList["UA"] < this.keyTimeList["DA"]  )			U = false;
		else if( this.keyTimeList["UA"] > this.keyTimeList["DA"]  )	D = false;
	}
	if( !R && !L )						this.heading.x = 0;
	else if ( R && L ) {
		if( this.keyTimeList["RA"] < this.keyTimeList["LA"]  )			R = false;
		else if( this.keyTimeList["RA"] > this.keyTimeList["LA"]  )	L = false;
	}

	if (D)								this.heading.y = 1;
	else if (U)							this.heading.y = -1;
	if (R)							this.heading.x = 1;
	else if (L)							this.heading.x = -1;



	if(this.heading.x != 0 || this.heading.y != 0) {
		this.lastHeading = {x:this.heading.x,y:this.heading.y};
	}

	if(this.actionMode == "MODE_STILL" || this.actionMode == "MODE_MOVING")
	{
		if(this.heading.x == 0 && this.heading.y == 0)	this.actionMode = "MODE_STILL";
		if(this.heading.x != 0 || this.heading.y != 0)	this.actionMode = "MODE_MOVING";
	}
};
CharActor.prototype.updateCurrentAnimation = function() {
};
CharActor.prototype.shoot = function() {
				if(this.debugMode==1)	return;
	var rock = PlayerShotActor.alloc();
	rock.updatePosition(this.position);
	rock.heading.x=0;
	rock.heading.y=-1;
	rock.shiftPosition({x:rock.heading.x*this.size.w/2,y:rock.heading.y*this.size.h/2});
	rock.firer=this;

    GAMEMODEL.gameSession.gameWorldList[0].addActor(rock,'playerbullet');

	if(GAMEVIEW.BoxIsInCamera(this.absBox)) {
		var r=0.9+ 0.3*Math.random();
		var v=0.55+ 0.1*Math.random();
//		if(Math.random() > 0.6)		this.playSound(4,v,r);
	}
};
CharActor.prototype.checkDeath = function() {
	if(this.debugMode==1)				return;
	if(this.deathTimer.started)	return;
	if(this.curHealthRadius < 0)		this.beginDeath();
	if(this.health < 0)			this.beginDeath();
};
CharActor.prototype.checkEnd = function() {
	if(!this.deathTimer.started)		return;

	var cycleobj = this.deathTimer.getCycle();

//	var curtime = GAMEMODEL.getTime();
//	if(curtime > (this.deathStart+this.deathClock))	{
	if(cycleobj.cycled) {
		this.alive = false;
		GAMEMODEL.endGame();
	}
};
CharActor.prototype.beginDeath = function() {
	this.deathTimer.startTimer();
//	this.deathStart = GAMEMODEL.getTime();
//	this.deathBegin = true;
	if(GAMEVIEW.BoxIsInCamera(this.absBox))
	{
		var r =	0.9 + 0.3 * Math.random();
		var v = 1.45 + 0.1 * Math.random();

		this.playSound(2, v, r);
	}

};
CharActor.prototype.updateDeath = function() {
	var curtime = GAMEMODEL.getTime();
	var deathDiff = (curtime - this.deathTimer.startTime)/this.deathTimer.lifeTime;

	this.deathRadius = 5 + 50*(deathDiff);
	if( (deathDiff) > 0.5)		this.deathRadius=0;
};
CharActor.prototype.collide = function(act) {
	Actor.prototype.collide.call(this,act);
};
CharActor.prototype.collideType = function(act) {
//	if(act instanceof BlockActor)		return true;
	return false;
};
CharActor.prototype.collideVs = function(act) {
/*	if(act instanceof BlockActor)
	{
		var interBox = GAMEGEOM.BoxIntersection(this.absBox, act.absBox);
		var interCenter = {x:0,y:0};
		interCenter.x = interBox.x + interBox.w/2;
		interCenter.y = interBox.y + interBox.h/2;

		var actCenter = {x:0,y:0};
		actCenter.x = act.absBox.x + act.absBox.w/2;
		actCenter.y = act.absBox.y + act.absBox.h/2;
	}	/**/
};


CharActor.prototype.readInput = function(inputobj)
{
	var keyused = false;
	var keyids = GAMECONTROL.keyIDs;
	if(this.stunTimer.running && inputobj.keypress == true) {return false;}

	var keylist = {};
	keylist['KEY_SPACEBAR'] = 'SP';
	keylist['KEY_ARROW_UP'] = 'UA';
	keylist['KEY_W'] = 'UA';
	keylist['KEY_ARROW_DOWN'] = 'DA';
	keylist['KEY_S'] = 'DA';
	keylist['KEY_ARROW_RIGHT'] = 'RA';
	keylist['KEY_D'] = 'RA';
	keylist['KEY_ARROW_LEFT'] = 'LA';
	keylist['KEY_A'] = 'LA';

	for(var keyname in keylist) {
		if(keyids[keyname] == inputobj.keyID) {
			keyused = true;
			var id = keylist[keyname];
			if(inputobj.keypress == true)
			{
				this.keyTimeList[id] = GAMEMODEL.getTime();
				if(this.keyStateList[id] == false)		this.newPressList[id] = true;
				if(this.keyStateList[id] == false)		this.keyPressList[id] = this.keyTimeList[id];
			}
			if(inputobj.keypress == false)					this.newPressList[id] = false;
			this.keyStateList[id] = inputobj.keypress;
		}
	}
	if(keyids['KEY_1'] == inputobj.keyID) {
		keyused = true;
		if(inputobj.keypress == false)		LEVELLOADER.loadLevel("build");
	}
	if(keyids['KEY_2'] == inputobj.keyID) {
		keyused = true;
		if(inputobj.keypress == false)		LEVELLOADER.loadLevel("test");
	}
	if(keyids['KEY_3'] == inputobj.keyID) {
		keyused = true;
		if(inputobj.keypress == false)		LEVELLOADER.loadLevel("open");
	}
	if(keyids['KEY_T'] == inputobj.keyID) {
		keyused = true;
		if(inputobj.keypress == false)		LEVELLOADER.loadLevel(GAMEMODEL.currentLevel+1);
		if(inputobj.keypress == false)
		{
//			this.damage(2.0,1.0,'hurt');
		}
	}


	for(var i in this.controlLinks) {
			if(typeof this.controlLinks[i].readInput === "function") {
					this.controlLinks[i].readInput(inputobj);
			}
	}

	return keyused;
};
CharActor.prototype.damage = function(dmg,stun,type,ints=1.0) {
	this.stunTimer.lifeTime = this.stunTimer.baseLifeTime * stun;
	this.stunTimer.startTimer();

	if(type == 'hurt') {
		this.health-=dmg;
		this.hurtTimer.lifeTime = this.hurtTimer.baseLifeTime * stun;
		this.hurtTimer.startTimer();
		this.hurtIntensity=dmg*ints;

		var r=0.3+ 0.1*Math.random();
		var v=0.55+ 0.1*Math.random();
		this.playSound(1,v,r);
	}
	else if(type == 'stun') {
		var r=0.4+ 0.2*Math.random();
		var v=0.45+ 0.1*Math.random();
		this.playSound(1,v,r);
	}
};
CharActor.prototype.heal = function(heal,stun,type,ints=1.0) {
//	this.healFlashTimer.lifeTime = this.healFlashTimer.baseLifeTime * stun;
//	this.healFlashTimer.startTimer();

//	if(type == 'heal') {()
		this.health+=heal;
		if(this.health > this.maxhealth)	this.health = this.maxhealth;
		this.healTimer.lifeTime = this.healTimer.baseLifeTime * stun;
		this.healTimer.startTimer();
		this.healIntensity=heal*ints;

		if(this.healIntensity < 1.0) {
			var r = 0.85 + 0.1 * Math.random();
			var v = 0.05 + 0.1 * Math.random();
			this.playSound(3, v, r);
		}
//	}
};
CharActor.prototype.hitSwitch = function(type,posX,posY,ints=1.0) {
//	this.healFlashTimer.lifeTime = this.healFlashTimer.baseLifeTime * stun;
//	this.healFlashTimer.startTimer();

		this.switchTimer.lifeTime = this.switchTimer.baseLifeTime;
		this.switchTimer.startTimer();
		this.switchIntensity=ints;
		this.switchPosX=posX;
		this.switchPosY=posY;
};


CharActor.alloc = function() {
	var vc = new CharActor();
	vc.init();
	return vc;
};
