// CommonJS ClassLoader Hack
var classLoadList = ["GameResources"];
if(typeof GameEngine === "undefined")     var GameEngine = module.parent.exports;     // Direct Load
function _loadJSEngineClasses(opts) {
	var classes = GameEngine.loadJS( __dirname, [], opts, classLoadList );
	for(var i in classes) {if(eval("typeof "+i+" === 'undefined'")) {eval(""+i+" = classes[i];");}};
} _loadJSEngineClasses({"mode":"loadneeds"});


GameResources.classList =
[
      //    Start UpItems
      [
				{'name':'BufferLoad',     'path':   'core/loaders/buffer_load.js',      'needs':[],          'uses':[],          },
				{'name':'ContentLoader',     'path':   'core/content_loader.js',      'needs':[],          'uses':[],          },
				{'name':'AssetLoader',     'path':   'core/loaders/asset_loader.js',      'needs':["ContentLoader"],          'uses':[],          },
				{'name':'FileLoader',     'path':   'core/loaders/file_loader.js',      'needs':["ContentLoader"],          'uses':[],          },
      ],

      //    Core Game Engine Components
      [
        {'name':'GAMEGEOM',       'path':   'FDZ_js/game_geometrics.js',     'needs':[],          'uses':[],          },
        {'name':'GAMECONTROL',    'path':   'FDZ_js/game_control.js',        'needs':[],          'uses':[],          },
        {'name':'GAMESOUNDS',     'path':   'FDZ_js/game_sounds.js',         'needs':[],          'uses':["BufferLoad"],          },
        {'name':'GAMEMUSIC',      'path':   'FDZ_js/game_music.js',          'needs':[],          'uses':[],          },
        {'name':'GAMEVIEW',       'path':   'FDZ_js/game_view.js',           'needs':[],          'uses':["GameCamera"],          },
        {'name':'GAMEANIMATIONS', 'path':   'FDZ_js/game_animations.js',     'needs':[],          'uses':[],          },
        {'name':'GAMEMODEL',      'path':   'FDZ_js/game_model.js',          'needs':[],          'uses':["Actor","SessionActor","GameCamera","GameClock","ScreenManager"],          },
      ],

      //    Secondary Game Engine Components
      [
        {'name':'GAMELOADER',       'path':   'FDZ_js/game_loader.js',         'needs':[],          'uses':[],          },
        {'name':'RenderEngine',     'path':   'FDZ_js/gameview/render_engine.js',       'needs':[],          'uses':[],          },
      ],

      //    Base Engine Components
      [
        {'name':'TimerObj',       'path':   'FDZ_js/actors/timer.js',       'needs':[],          'uses':[],          },
        {'name':'Actor',          'path':   'FDZ_js/actors/actor.js',       'needs':[],          'uses':[],          },
      ],

      [
        {'name':'GameCamera',       'path':  'FDZ_js/gamedisplay/gamecamera.js',     'needs':["Actor"],          'uses':[],          },
        {'name':'ScreenManager',    'path':  'FDZ_js/gamedisplay/screen_manager.js',     'needs':["Actor"],          'uses':["GameCamera"],          },
        {'name':'ViewScreen',       'path':  'FDZ_js/gamedisplay/view_screen.js',     'needs':["Actor"],          'uses':[],          },
      ],

			[
        {'name':'MenuActor',       'path':  'FDZ_js/gamedisplay/screens/menuactor.js',     'needs':["Actor"],          'uses':[],          },
				{'name':'MenuItemActor',       'path':  'FDZ_js/gamedisplay/screens/menuitemactor.js',     'needs':["Actor"],          'uses':[],          },
      ],

      [
        {'name':'GameClock',       'path':  'FDZ_js/gamemodel/gameclock.js',       'needs':[],          'uses':[],          },
        {'name':'AreaActor',       'path':  'FDZ_js/gamemodel/areaactor.js',       'needs':["Actor"],          'uses':[],          },
        {'name':'SessionActor',    'path':  'FDZ_js/gamemodel/session_actor.js',     'needs':["Actor"],          'uses':["WorldActor","GameCamera","GameClock"],          },
        {'name':'WorldActor',      'path':  'FDZ_js/gamemodel/world_actor.js',     'needs':["Actor"],          'uses':[],          },
      ],

      [
        {'nameset':['ImageFrame','ImageFrameSet'],
                                  'path':  'FDZ_js/graphics/imgframe.js',     'needs':[],          'uses':[],          },
        {'nameset':['AnimationFrame,AnimationSequence,AnimationCollection'],
                                  'path':  'FDZ_js/graphics/animframe.js',     'needs':[],          'uses':[],          },
      ],

      [
        {'name':'ShapeObject',       'path':  'FDZ_js/module/shapes/shapeobj.js',       'needs':[],          'uses':[],          },
        {'name':'CircleShape',       'path':  'FDZ_js/module/shapes/circleshape.js',       'needs':["ShapeObject"],      'uses':[],          },
				{'name':'BoxShape',     		  'path':  'FDZ_js/module/shapes/boxshape.js',       'needs':["ShapeObject"],      'uses':[],          },
				{'name':'SegmentShape',       'path':  'FDZ_js/module/shapes/segmentshape.js',       'needs':["ShapeObject"],      'uses':[],          },
      ],

      [
        {'name':'ActionObject',       'path':  'FDZ_js/module/actions/actionobj.js',       'needs':[],          'uses':[],          },
        {'name':'ActionList',       'path':  'FDZ_js/module/actions/actionlist.js',       'needs':[],      'uses':[],          },
      ],

      [
        {'name':'ActionModule',       'path':  'FDZ_js/module/actionmodule.js',       'needs':[],          'uses':[],          },
        {'name':'StepModule',       'path':  'FDZ_js/module/stepmodule.js',       'needs':[],          'uses':[],          },
        {'name':'AnimationModule',       'path':  'FDZ_js/module/animationmodule.js',       'needs':[],          'uses':[],          },
        {'name':'CollisionModule',       'path':  'FDZ_js/module/collisionmodule.js',       'needs':[],          'uses':[],          },
        {'name':'MotionModule',       'path':  'FDZ_js/module/motionmodule.js',       'needs':["ActionModule"],          'uses':[],          },
      ],

      [
        {'name':'MoveActorComponent',       'path':  'FDZ_js/module/movescripts/movecomponent.js',       'needs':[],          'uses':[],          },
        {'name':'MoveActorBasicPath',       'path':  'FDZ_js/module/movescripts/basicpath.js',       'needs':["MoveActorComponent"],          'uses':[],          },
        {'name':'MoveActorBasicProgress',       'path':  'FDZ_js/module/movescripts/basicprogress.js',       'needs':["MoveActorComponent"],          'uses':[],          },
      ],

      [
        {'name':'MoveActor',       'path':  'FDZ_js/module/movescripts/moveactor.js',       'needs':["ActionObject"],          'uses':[],          },
        {'nameset':['MoveActorDuration','DurationByTime','DurationByDistance'],
                                  'path':  'FDZ_js/module/movescripts/durations.js',     'needs':["MoveActorComponent"],          'uses':[],          },
        {'nameset':['MoveActorHeading','HeadingByVector'],
                                'path':  'FDZ_js/module/movescripts/headings.js',     'needs':["MoveActorComponent"],          'uses':[],          },
        {'nameset':['MoveActorIncrement','IncrementBySpeed'],
                                'path':  'FDZ_js/module/movescripts/increments.js',     'needs':["MoveActorComponent"],          'uses':[],          },
        {'nameset':['CubicBezierPath','QuadBezierPath','LinearPath'],
                                'path':  'FDZ_js/module/movescripts/paths.js',     'needs':["MoveActorBasicPath"],          'uses':[],          },
        {'name':'LinearProgress',       'path':  'FDZ_js/module/movescripts/progress.js',       'needs':["MoveActorBasicProgress"],          'uses':[],          },

      ],


      [
        {'name':'WindowObj',       'path':  'ex_js2/actors/timewindow.js',       'needs':[],          'uses':["TimerObj","GAMEMODEL"],          },
				{'name':'WireGrid',       'path':  'ex_js2/actors/wiregrid.js',       'needs':["Actor"],          'uses':["WindowObj","GAMEMODEL"],          },
				{'name':'CircleActor',     'path':  'ex_js2/actors/circleactor.js',       'needs':["Actor"],          'uses':["TimerObj","MotionModule","CharActor","GAMEMODEL"],          },
				{'name':'CharActor',       'path':  'ex_js2/actors/charactor.js',       'needs':["Actor"],          'uses':["TimerObj","MotionModule","GAMEMODEL"],          },
				{'name':'EnemyActor',       'path':  'ex_js2/actors/enemyactor.js',       'needs':["Actor"],          'uses':["GAMEMODEL"],          },
				{'name':'TextActor',       'path':  'ex_js2/actors/textactor.js',       'needs':["EnemyActor"],          'uses':["GAMEMODEL"],          },
      ],
			[
        {'name':'GameWorld',       'path':  'ex_js2/gamemodel/gameworld.js',       'needs':["WorldActor"],          'uses':["Actor","CharActor","CircleEnemy","GAMEGEOM","GAMEMODEL"],          },
				{'name':'GameArea',       'path':  'ex_js2/gamemodel/gamearea.js',       'needs':["AreaActor"],          'uses':["RockActor"],          },
				{'name':'LEVELLOADER',       'path':  'ex_js2/gamemodel/loadLevel.js',       'needs':[],          'uses':["GAMEMODEL"],          },
			],
];
GameResources.codeList =
[
      [
        {'label':'ranseedloader',       'path':  'core/seedrandom.davidbau.2.4.0.min.js',       'needs':[],          'uses':[],          },
				{'label':'xxxLt',               'path':  'ex_js2/gamelevels/leveltest.js',       'needs':[],                     'uses':["GameWorld","GAMEMODEL","CharActor","WireGrid","CircleActor","GAMEMUSIC","TextActor"],          },
				{'label':'xxxLb',               'path':  'ex_js2/gamelevels/levelbuild.js',       'needs':[],                     'uses':["GameWorld","GAMEMODEL","CharActor","WireGrid","CircleActor","GAMEMUSIC","TextActor"],          },
				{'label':'xxxLo',               'path':  'ex_js2/gamelevels/levelopen.js',       'needs':[],                     'uses':["GameWorld","GAMEMODEL","CharActor","WireGrid","CircleActor","GAMEMUSIC","TextActor"],          },
        {'label':'xxxL0',               'path':  'ex_js2/gamelevels/level0.js',       'needs':[],                     'uses':["GameWorld","GAMEMODEL","CharActor","WireGrid","CircleActor","GAMEMUSIC","TextActor"],          },
				{'label':'xxxL1',               'path':  'ex_js2/gamelevels/level1.js',       'needs':[],                     'uses':["GameWorld","GAMEMODEL","CharActor","WireGrid","CircleActor","GAMEMUSIC","TextActor"],          },
				{'label':'xxxL2',               'path':  'ex_js2/gamelevels/level2.js',       'needs':[],                     'uses':["GameWorld","GAMEMODEL","CharActor","WireGrid","CircleActor","GAMEMUSIC","TextActor"],          },


        {'label':'xxxx2',               'path':  'ex_js2/loadoverrides.js',       'needs':[],          'uses':["Actor","AnimationCollection"],          },
        {'label':'xxxx3',               'path':  'ex_js2/gameoverrides.js',       'needs':['xxxx2'],          'uses':["GAMEVIEW","GAMEMODEL","GameWorld","Actor"],          },
      ],
];
GameResources.initCodeList =
[
      //    Start UpItems
      [
				{'label':'InitCode',     'path':   'core/codeblocks/game_initialize.js',      'needs':[],          'uses':[],          },
				{'label':'LoadUpCode',     'path':   'core/codeblocks/game_loadup.js',      'needs':['InitCode'],          'uses':[],          },
      ],

];
