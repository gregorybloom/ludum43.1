GAMEVIEW.drawAll = function()
{
  if(GAMEMODEL.modelCamera != null && GAMEMODEL.modelCamera.target instanceof Actor) {
      GAMEMODEL.modelCamera.updatePosition( GAMEMODEL.modelCamera.target.position );
  }

//    this.context.fillStyle = "#FFFFFF";
//    this.context.fillRect( 0, 0, this.screen.w, this.screen.h );
    for(var i in this.contextArr) {
        if( this.contextArr[i].drawnOn == true || i==0) {
            this.contextArr[i].context.clearRect(0,0,800,600);
            delete this.contextArr[i].drawnOn;
        }
    }

    GAMEMODEL.drawAll();


  //    if(this.deathBegin)		   transf = {actions:[{type:'a',alpha:Math.max(0,(1-2*t)/2)}]};
  //    if(this.exitBegin)		   transf = {actions:[{type:'a',alpha:Math.max(0,(1-2*t)/2)}]};


//    GAMEVIEW.drawCircle({x:200,y:49500},15,"#9900ff",2);

    var fps = 1000 / this.avgTick;
    fps = Math.floor( fps );
    var pauseContext = this.contextArr[2].context;
      if(GAMEMODEL.gameMode === "GAME_MUSICPAUSE")
      {
          pauseContext.fillStyle = "rgba(155,155,255,0.35)";
          pauseContext.fillRect( 0, 0, this.screen.w, this.screen.h );

          var ScreenPt = {x:10,y:555};
          var str = "MUSIC LOADING...";
          pauseContext.lineWidth = "3";
          pauseContext.strokeStyle = "#FFFFFF";
          pauseContext.font = "10pt Arial";
          pauseContext.strokeText(str,ScreenPt.x,ScreenPt.y);
          pauseContext.fillStyle = "#000000";
          pauseContext.fillText(str,ScreenPt.x,ScreenPt.y);
      }
      else if(GAMEMODEL.gameMode === "GAME_PAUSE")
      {
          pauseContext.fillStyle = "rgba(255,255,255,0.35)";
          pauseContext.fillRect( 0, 0, this.screen.w, this.screen.h );

          var ScreenPt = {x:10,y:555};
          var str = "GAME PAUSED";
          pauseContext.lineWidth = "3";
          pauseContext.strokeStyle = "#FFFFFF";
          pauseContext.font = "10pt Arial";
          pauseContext.strokeText(str,ScreenPt.x,ScreenPt.y);
          pauseContext.fillStyle = "#000000";
          pauseContext.fillText(str,ScreenPt.x,ScreenPt.y);
      }
      else if(GAMEMODEL.modelClock && GAMEMODEL.modelClock.timeRate != 1.0) {
        pauseContext.fillStyle = "rgba(0,0,255,0.05)";
        pauseContext.fillRect( 0, 0, this.screen.w, this.screen.h );
      }

/*
    var ScreenPt = {x:(GAMEVIEW.screen.w-50),y:(GAMEVIEW.screen.h-20)};
    this.context.lineWidth = "3";
    this.context.strokeStyle = "#FFFFFF";
    this.context.font = "10pt Arial";
    this.context.strokeText(fps+" fps",ScreenPt.x,ScreenPt.y);
    this.context.fillStyle = "#000000";
    this.context.fillText(fps+" fps",ScreenPt.x,ScreenPt.y);

/*    var ScreenPt = {x:10,y:585};
    var str = GAMEMODEL.playerScore+" pts";
    this.context.lineWidth = "3";
    this.context.strokeStyle = "#FFFFFF";
    this.context.font = "10pt Arial";
    this.context.strokeText(str,ScreenPt.x,ScreenPt.y);
    this.context.fillStyle = "#000000";
    this.context.fillText(str,ScreenPt.x,ScreenPt.y);
/**/
    var ScreenPt = {x:110,y:585};
    var str = "";
    if(GAMEMODEL.gameSession != null && GAMEMODEL.gameSession.gameWorld != null)
    {
        str=Math.floor(GAMEMODEL.gameSession.gameWorld.dropper.progress/2)+" progress";
    }
    this.context.lineWidth = "3";
    this.context.strokeStyle = "#FFFFFF";
    this.context.font = "10pt Arial";
    this.context.strokeText(str,ScreenPt.x,ScreenPt.y);
    this.context.fillStyle = "#000000";
    this.context.fillText(str,ScreenPt.x,ScreenPt.y);

};
GAMEMODEL.update = function() {
    if(GAMEMODEL.modelCamera != null && GAMEMODEL.modelCamera.target instanceof Actor) {
        GAMEMODEL.modelCamera.updatePosition( GAMEMODEL.modelCamera.target.position );
    }
};
GAMEMODEL.readInput = function(inputobj)
{
    var keyused = false;
    if(GAMEMODEL.modelCamera != null)
    {
        var keyids = GAMECONTROL.keyIDs;

/*        if(keyids['KEY_PAGE_UP'] == inputobj.keyID)
        {
            keyused = true;
            if(!inputobj.keypress) {
              var GW = GAMEMODEL.gameSession.gameWorldList[0];
              for(var i in this.gameActors) {
                if(this.gameActors[i] instanceof WireGrid) {
                  this.gameActors[i]
                }
              }
            }
        } /**/

        if(keyids['KEY_DASH'] == inputobj.keyID)
        {
            keyused = true;
            if(!inputobj.keypress)      GAMEMODEL.modelCamera.zoomOut();
        }
        if(keyids['KEY_EQUALS'] == inputobj.keyID)
        {
            keyused = true;
            if(!inputobj.keypress)      GAMEMODEL.modelCamera.zoomIn();
        }

        if(keyids['KEY_O'] == inputobj.keyID)
        {
            keyused = true;
//            if(!inputobj.keypress)      GAMEMUSIC.toggleAudio();
        }
        if(keyids['KEY_N'] == inputobj.keyID)
        {
            keyused = true;
//            if(!inputobj.keypress)      GAMEMUSIC.nextAudio();
        }
        if(keyids['KEY_SQUAREBR_RIGHT'] == inputobj.keyID)
        {
            keyused = true;
            if(!inputobj.keypress)      GAMEMUSIC.volumeUp();
        }
        if(keyids['KEY_SQUAREBR_LEFT'] == inputobj.keyID)
        {
            keyused = true;
            if(!inputobj.keypress)      GAMEMUSIC.volumeDown();
        }
        if(keyids['KEY_M'] == inputobj.keyID)
        {
            keyused = true;
            if(!inputobj.keypress)
            {
                if(GAMEMUSIC.mute)    GAMEMUSIC.mute=false;
                else {
                    GAMEMUSIC.mute=true;
                    var player = GAMEMODEL.gameSession.gamePlayer;
                    for(var i=0; i<10;i++) {
                        if(typeof player.playingSounds[i] !== "undefined") {
                //          console.log('this '+this.speed+' num '+num+' i '+i +' newsound '+newsound);
                            if(player.playingSounds[i].source)        player.playingSounds[i].source.stop();
                            delete player.playingSounds[i];
                        }
                    }
                }
            }
        }

        if(keyids['KEY_P'] == inputobj.keyID)
        {
            keyused = true;
            if(!inputobj.keypress)
            {
                GAMEMODEL.togglePause();

                if(GAMEMUSIC.musicOn)
                {
                    if(this.gameMode === "GAME_PAUSE" && GAMEMUSIC.playing)     GAMEMUSIC.pauseAudio();
                    else if(this.gameMode === "GAME_RUN" && !GAMEMUSIC.playing) GAMEMUSIC.pauseAudio();
                }

            }
        }
    }
    return keyused;
};

GAMEMODEL.update = function() {
    if(GAMEMODEL.modelCamera != null && GAMEMODEL.modelCamera.target instanceof Actor) {
        GAMEMODEL.modelCamera.updatePosition( GAMEMODEL.modelCamera.target.position );
    }
};

GAMEMODEL.loadGame = function()
{
    GAMEMODEL.activeObjs = 0;


    console.log('loaded game');
    GAMEMODEL.currentLevel = 0;
    LEVELLOADER.loadLevel(GAMEMODEL.currentLevel);
};

GAMEMODEL.fillDropper = function(dropper)
{
};
