
LEVELLOADER.level0 = function()
{

      var GW = GameWorld.alloc();
      GAMEMODEL.gameSession.gameWorldList[0]=GW;
      GW.load();
      GW.size = {w:1200,h:1200};
      GW.updatePosition({x:(GW.size.w/2),y:(GW.size.h/2)});
  //    GW.updatePosition({x:0,y:0});

  /*
      var Tx0 = TextActor.alloc();
      Tx0.fontSize = 28;
      Tx0.text = "YOU ARE THE TRUCK";
      Tx0.updatePosition({x:550,y:50});
      this.gameSession.gameWorld.addActor(Tx0,'act');
  /**/

      var C = CharActor.alloc();
      C.updatePosition({x:200,y:250});
      GW.gamePlayer = C;
      GW.addActor(GW.gamePlayer,'player');
      GW.gamePlayer.parentWorld = GW;

      GAMEMODEL.modelCamera.target = C;
      GW.addActor(C,'act');


            var TA = TextActor.alloc();
            TA.loadingData({'fsize':24,"text":"Game Dev:  Gregory Bloom"});
            TA.updatePosition({x:-50,y:500});
            TA.fadeTime *= 2;
            TA.intoTime *= 2;
            GW.addActor(TA,'act');
            var TA = TextActor.alloc();
            TA.loadingData({'fsize':24,"text":"Music:  Jeremy 'Nitacku' Ouillette"});
            TA.updatePosition({x:-50,y:550});
            TA.fadeTime *= 2;
            TA.intoTime *= 2;
            GW.addActor(TA,'act');


      var TA = TextActor.alloc();
      TA.loadingData({'fsize':54,"text":"Dance On The Wire"});
      TA.updatePosition({x:-300,y:350});
      GW.addActor(TA,'act');

      var arrgh = [
        {'d':{'fsize':24,"text":"Level 1"},'p':{x:375,y:505}},
        {'d':{'fsize':24,"text":"Tutorial =>"},'p':{x:360,y:380}},
        {'d':{'fsize':20,"text":"With every pulse..."},'p':{x:760,y:380}},
        {'d':{'fsize':20,"text":"...you move on the beat"},'p':{x:900,y:430}},
        {'d':{'fsize':20,"text":"To change direction..."},'p':{x:1300,y:380}},
        {'d':{'fsize':20,"text":" just before you move..."},'p':{x:1420,y:430}},
        {'d':{'fsize':20,"text":"tap an 'arrow' when the points 'flash'!"},'p':{x:1440,y:460}},
        {'d':{'fsize':20,"text":"But miss a beat and you'll lose energy..."},'p':{x:1420,y:530}},
        {'d':{'fsize':20,"text":"A 'miss' on a forward direction only stuns."},'p':{x:1350,y:680}},
        {'d':{'fsize':20,"text":"Try 'moving' forward on a beat to regain some energy!"},'p':{x:1300,y:730}},
        {'d':{'fsize':18,"text":"(to Level 1)"},'p':{x:1050,y:830}},
        {'d':{'fsize':20,"text":"Lastly, your default path will be 'green' or 'blue'..."},'p':{x:1300,y:830}},
        {'d':{'fsize':20,"text":"...and different square 'junctions' behave differently!"},'p':{x:1300,y:930}}
      ];
      for(var i in arrgh) {
        var TA1 = TextActor.alloc();
        TA1.loadingData(arrgh[i]['d']);
        TA1.updatePosition(arrgh[i]['p']);
        GW.addActor(TA1,'act');
        TA1.lifeTime *= 100;
        TA1.fadeTime *= 100;
        TA1.intoTime *= 100;
      }

      var WG = WireGrid.alloc();
      WG.updatePosition({x:400,y:400});
      GW.addActor(WG,'act');

      WG.addPoint('-4', {x:-450,y:0}, {});
      WG.addPoint('-3', {x:-400,y:0}, {}, {pts:['-4','-3']});
      WG.addPoint('-2', {x:-350,y:0}, {}, {pts:['-3','-2']});
      WG.addPoint('-1', {x:-300,y:0}, {}, {pts:['-2','-1']});
      WG.addPoint('0', {x:-250,y:0}, {}, {pts:['-1','0']});
      WG.addPoint('1', {x:-200,y:0}, {}, {pts:['0','1']});
      WG.addPoint('2', {x:-100,y:0}, {}, {pts:['1','2']});
      WG.addPoint('3', {x:-50,y:0}, {}, {pts:['2','3']});
      WG.addPoint('4', {x:0,y:0}, {}, {pts:['3','4']});
      WG.addPoint('5', {x:50,y:0}, {}, {pts:['4','5']});
      WG.addPoint('6', {x:100,y:0}, {}, {pts:['5','6']});
      WG.addPoint('7', {x:150,y:0}, {}, {pts:['6','7']});

      WG.addPoint('8', {x:500,y:0}, {}, {pts:['7','8']});
      WG.addPoint('9', {x:550,y:0}, {}, {pts:['8','9']});
      WG.addPoint('10', {x:600,y:0}, {}, {pts:['9','10']});
      WG.addPoint('11', {x:650,y:0}, {}, {pts:['10','11']});

      WG.addPoint('12', {x:1000,y:0}, {}, {pts:['11','12']});
      WG.addPoint('13', {x:1050,y:0}, {}, {pts:['12','13']});
      WG.addPoint('14', {x:1100,y:0}, {}, {pts:['13','14']});
      WG.addPoint('15', {x:1150,y:0}, {}, {pts:['14','15']});
      WG.addPoint('16', {x:1200,y:0}, {}, {pts:['15','16']});
      WG.addPoint('17', {x:1250,y:0}, {}, {pts:['16','17']});
      WG.addPoint('18', {x:1300,y:0}, {}, {pts:['17','18']});
      WG.addPoint('19', {x:1350,y:0}, {}, {pts:['18','19']});
      WG.addPoint('20', {x:1400,y:0}, {}, {pts:['19','20']});
      WG.addPoint('20b', {x:1400,y:100}, {}, {pts:['20','20b']});
      WG.addPoint('20b2', {x:1000,y:100}, {}, {pts:['20b','20b2']});
      WG.addLink({pts:['20b2','12']});

      WG.addPoint('14a', {x:1100,y:-100}, {}, {pts:['14','14a'],junct:"switch"});
      WG.addPoint('15a', {x:1150,y:-100}, {}, {pts:['15','15a'],junct:"switch"});
      WG.addPoint('16a', {x:1200,y:-100}, {}, {pts:['16','16a'],junct:"switch"});
      WG.addPoint('17a', {x:1250,y:-100}, {}, {pts:['17','17a'],junct:"switch"});
      WG.addPoint('18a', {x:1300,y:-100}, {}, {pts:['18','18a'],junct:"switch"});
      WG.addPoint('19a', {x:1350,y:-100}, {}, {pts:['19','19a'],junct:"switch"});

      WG.addPoint('20a', {x:1400,y:-100}, {}, {pts:['19a','20a']});

      WG.addLink({pts:['14a','15a']});
      WG.addLink({pts:['15a','16a']});
      WG.addLink({pts:['16a','17a']});
      WG.addLink({pts:['17a','18a']});
      WG.addLink({pts:['18a','19a']});

      WG.addPoint('21', {x:1450,y:-100}, {}, {pts:['20a','21']});
      WG.addPoint('22', {x:1500,y:-100}, {}, {pts:['21','22']});

      WG.addPoint('23', {x:1500,y:300}, {}, {pts:['22','23']});
      WG.addPoint('24', {x:1450,y:300}, {}, {pts:['23','24']});
      WG.addPoint('25', {x:1400,y:300}, {}, {pts:['24','25']});
      WG.addPoint('26', {x:1350,y:300}, {}, {pts:['25','26']});
      WG.addPoint('27', {x:1300,y:300}, {}, {pts:['26','27']});

      WG.addPoint('28', {x:1250,y:300}, {}, {pts:['27','28']});
      WG.addPoint('29', {x:1200,y:300}, {}, {pts:['28','29']});
      WG.addPoint('30', {x:1150,y:300}, {}, {pts:['29','30']});
      WG.addPoint('31', {x:1100,y:300}, {}, {pts:['30','31']});
      WG.addPoint('32', {x:1050,y:300}, {}, {pts:['31','32']});
      WG.addPoint('33', {x:1000,y:300}, {}, {pts:['32','33']});
      WG.addPoint('34', {x:950,y:300}, {}, {pts:['33','34']});
      WG.addPoint('35', {x:900,y:300}, {}, {pts:['34','35']});
      WG.addPoint('36', {x:850,y:300}, {}, {pts:['35','36']});

      WG.addPoint('37', {x:850,y:450}, {}, {pts:['36','37']});

      WG.addPoint('38', {x:900,y:450}, {}, {pts:['37','38']});
      WG.addPoint('39', {x:950,y:450}, {}, {pts:['38','39']});
      WG.addPoint('40', {x:1000,y:450}, {}, {pts:['39','40']});
      WG.addPoint('41', {x:1050,y:450}, {}, {pts:['40','41']});
      WG.addPoint('42', {x:1100,y:450}, {}, {pts:['41','42']});
      WG.addPoint('43', {x:1150,y:450}, {}, {pts:['42','43']});
      WG.addPoint('44', {x:1200,y:450}, {}, {pts:['43','44']});
      WG.addPoint('45', {x:1250,y:450}, {}, {pts:['44','45']});
      WG.addPoint('46', {x:1300,y:450}, {}, {pts:['45','46']});
      WG.addPoint('47', {x:1350,y:450}, {}, {pts:['46','47']});
      WG.addPoint('48', {x:1400,y:450}, {}, {pts:['47','48']});

      WG.addPoint('49', {x:1400,y:500}, {}, {pts:['48','49']});

      WG.addPoint('50', {x:1350,y:500}, {}, {pts:['49','50']});
      WG.addPoint('51', {x:1300,y:500}, {}, {pts:['50','51']});
      WG.addPoint('52', {x:1250,y:500}, {}, {pts:['51','52']});
      WG.addPoint('53', {x:1200,y:500}, {}, {pts:['52','53']});
      WG.addPoint('54', {x:1150,y:500}, {}, {pts:['53','54']});
      WG.addPoint('55', {x:1100,y:500}, {}, {pts:['54','55']});

      WG.addPoint('56', {x:1050,y:500}, {}, {pts:['55','56']});
      WG.addPoint('57', {x:1000,y:500}, {}, {pts:['56','57']});
      WG.addPoint('58', {x:950,y:500}, {}, {pts:['57','58']});
      WG.addPoint('59', {x:900,y:500}, {}, {pts:['58','59']});
      WG.addPoint('60', {x:850,y:500}, {}, {pts:['59','60']});
      WG.addLink({pts:['60','37']});

      WG.addLink({pts:['59','38']});
      WG.addLink({pts:['38','59']});
      WG.addLink({pts:['58','39']});
      WG.addLink({pts:['39','58']});
      WG.addLink({pts:['57','58','40'],junct:"switch"});
      WG.addLink({pts:['40','41','57'],junct:"switch"});
      WG.addLink({pts:['56','57','41'],junct:"switch"});
      WG.addLink({pts:['41','42','56'],junct:"switch"});
      WG.addLink({pts:['55','56','42'],junct:"switch"});
      WG.addLink({pts:['42','43','55'],junct:"switch"});
      WG.addLink({pts:['54','55','43'],junct:"switch"});
      WG.addLink({pts:['43','44','54'],junct:"switch"});
      WG.addLink({pts:['53','54','44'],junct:"switch"});
      WG.addLink({pts:['44','45','53'],junct:"switch"});
      WG.addLink({pts:['52','45']});
      WG.addLink({pts:['45','52']});
      WG.addLink({pts:['51','46']});
      WG.addLink({pts:['46','51']});

      WG.addLink({pts:['60a','37a']});

      WG.addPoint('61', {x:700,y:450}, {}, {pts:['37a','61']});

      WG.addObject('char',GW.gamePlayer,'-4');
      WG.addPoint('37a', {x:750,y:450}, {}, {pts:['37','38','37a'],junct:"switch"});
      WG.addPoint('60a', {x:750,y:500}, {}, {pts:['60','37','60a'],junct:"switch"});

      WG.addPoint('3b1', {x:-50,y:50}, {}, {pts:['3','3b1']});
      WG.addPoint('3b2', {x:0,y:50}, {}, {pts:['4','3b2']});
      WG.addPoint('3b3', {x:50,y:50}, {}, {pts:['5','3b3']});
      WG.addLink({pts:['3b2','3b1']});
      WG.addLink({pts:['3b3','3b2']});

      WG.addPoint('3bb1', {x:-50,y:100}, {}, {pts:['3b1','3bb1']});

/*

      WG.addPoint('6b', {x:0,y:100}, {}, {pts:['6b','1']});
      WG.addPoint('6ab', {x:66,y:100}, {});
      WG.addPoint('6aba', {x:66,y:50}, {}, {pts:['6ab','6aba']});

      WG.addPoint('6a', {x:133,y:100}, {}, {pts:['6a','6ab']});
      WG.addLink({pts:['6','6a'],type:"switch"});
      WG.addLink({pts:['8','6b']});

      WG.addPoint('2a', {x:100,y:-75}, {}, {pts:['2a','2']});
      WG.addLink({pts:['2','2a']});
/**/
      WG.addItem('exit','3bb1',{'type':'exit','ontouch':{'goToLevel':1}});
      WG.addItem('exit','61',{'type':'exit','ontouch':{'goToLevel':1}});




//      var CA = CircleActor.alloc();
//      GW.addActor(CA,'act');

//      WG.addObject('char',GW.gamePlayer,'-4');
//      WG.addObject('obj',CA,'4');


      GAMEMODEL.gameSession.gamePlayer = GW.gamePlayer;
      var actlist = GW.gameActors;

      GW.size = {w:3200,h:3200};
      GW.updatePosition({x:(GW.size.w/2),y:(GW.size.h/2)});

          GAMEMUSIC.currSong=0;
          GAMEMUSIC.stopAudio();
          GAMEMUSIC.playAudio();

          GAMEMODEL.modelCamera.zoom = 1.0;
          GAMEMODEL.modelCamera.zoomIn();

};
