
LEVELLOADER.levelOpen = function()
{

      var GW = GameWorld.alloc();
      GAMEMODEL.gameSession.gameWorldList[0]=GW;
      GW.load();
      GW.size = {w:1200,h:1200};
      GW.updatePosition({x:(GW.size.w/2),y:(GW.size.h/2)});
  //    GW.updatePosition({x:0,y:0});

  /*
      var Tx0 = TextActor.alloc();
      Tx0.fontSize = 28;
      Tx0.text = "YOU ARE THE TRUCK";
      Tx0.updatePosition({x:550,y:50});
      this.gameSession.gameWorld.addActor(Tx0,'act');
  /**/

      var C = CharActor.alloc();
      C.updatePosition({x:200,y:250});
      GW.gamePlayer = C;
      GW.addActor(GW.gamePlayer,'player');
      GW.gamePlayer.parentWorld = GW;

      GAMEMODEL.modelCamera.target = C;
      GW.addActor(C,'act');



      var WG = WireGrid.alloc();
      WG.updatePosition({x:400,y:400});
      GW.addActor(WG,'act');
      WG.addPoint('1', {x:0,y:0});
      WG.addPoint('2', {x:100,y:0}, {}, {pts:['1','2']});
      WG.addPoint('3', {x:150,y:0}, {}, {pts:['2','3']});
      WG.addPoint('4', {x:200,y:0}, {}, {pts:['3','4']});
/*
      WG.addPoint('5', {x:200,y:50}, {}, {pts:['4','5']});
      WG.addPoint('6', {x:200,y:100}, {}, {pts:['5','6']});
      WG.addPoint('7', {x:200,y:150}, {}, {pts:['6','7'],type:"switch"});
      WG.addPoint('8', {x:0,y:150}, {}, {pts:['7','8']});

      WG.addPoint('6b', {x:0,y:100}, {}, {pts:['6b','1']});
      WG.addPoint('6ab', {x:66,y:100}, {});
      WG.addPoint('6aba', {x:66,y:50}, {}, {pts:['6ab','6aba']});

      WG.addPoint('6a', {x:133,y:100}, {}, {pts:['6a','6ab']});
      WG.addLink({pts:['6','6a'],type:"switch"});
      WG.addLink({pts:['8','6b']});

      WG.addPoint('2a', {x:100,y:-75}, {}, {pts:['2a','2']});

      WG.addItem('exit','6aba',{'type':'exit','ontouch':{'goToLevel':1}});
/**/

      var TA = TextActor.alloc();
      TA.loadingData({'fsize':34,"text":"As far as I got.  Hope you enjoyed this brief peek..."});
      TA.updatePosition({x:100,y:250});
      TA.fadeTime *= 2;
      TA.intoTime *= 2;
      GW.addActor(TA,'act');



      var TA = TextActor.alloc();
      TA.loadingData({'fsize':24,"text":"Game Dev:  Gregory Bloom"});
      TA.updatePosition({x:300,y:450});
      TA.fadeTime *= 10;
      TA.intoTime *= 10;
      GW.addActor(TA,'act');
      var TA = TextActor.alloc();
      TA.loadingData({'fsize':24,"text":"Music:  Jeremy 'Nitacku' Ouillette"});
      TA.updatePosition({x:300,y:500});
      TA.fadeTime *= 10;
      TA.intoTime *= 10;
      GW.addActor(TA,'act');

/*
      var CA = CircleActor.alloc();
      GW.addActor(CA,'act');
      WG.addObject('obj',CA,'4');
/**/
      WG.addObject('char',GW.gamePlayer,'1');


      GAMEMODEL.gameSession.gamePlayer = GW.gamePlayer;
      var actlist = GW.gameActors;


          GAMEMUSIC.currSong=0;
          GAMEMUSIC.stopAudio();
          GAMEMUSIC.playAudio();

          GAMEMODEL.modelCamera.zoom = 1.0;
          GAMEMODEL.modelCamera.zoomIn();

};
