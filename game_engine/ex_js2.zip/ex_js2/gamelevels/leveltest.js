
LEVELLOADER.leveltest = function()
{

      var GW = GameWorld.alloc();
      GAMEMODEL.gameSession.gameWorldList[0]=GW;
      GW.load();
      GW.size = {w:1200,h:1200};
      GW.updatePosition({x:(GW.size.w/2),y:(GW.size.h/2)});
  //    GW.updatePosition({x:0,y:0});

  /*
      var Tx0 = TextActor.alloc();
      Tx0.fontSize = 28;
      Tx0.text = "YOU ARE THE TRUCK";
      Tx0.updatePosition({x:550,y:50});
      this.gameSession.gameWorld.addActor(Tx0,'act');
  /**/

      var C = CharActor.alloc();
      C.updatePosition({x:200,y:250});
      GW.gamePlayer = C;
      GW.addActor(GW.gamePlayer,'player');
      GW.gamePlayer.parentWorld = GW;

      GAMEMODEL.modelCamera.target = C;
      GW.addActor(C,'act');



      var WG = WireGrid.alloc();
      WG.updatePosition({x:400,y:400});
      GW.addActor(WG,'act');
      WG.addPoint('1', {x:0,y:0});
      WG.addPoint('2', {x:100,y:0}, {}, {pts:['1','2']});
      WG.addPoint('3', {x:150,y:0}, {}, {pts:['2','3']});
      WG.addPoint('4', {x:200,y:0}, {}, {pts:['3','4']});
      WG.addPoint('5', {x:200,y:50}, {}, {pts:['4','5']});
      WG.addPoint('6', {x:200,y:100}, {}, {pts:['5','6']});
      WG.addPoint('7', {x:200,y:150}, {}, {pts:['6','7'],junct:"switch"});
      WG.addPoint('8', {x:0,y:150}, {}, {pts:['7','8']});

      WG.addPoint('6b', {x:0,y:100}, {}, {pts:['6b','1']});
      WG.addPoint('6ab', {x:66,y:100}, {}, {pts:['6ab','6b']});
      WG.addPoint('6a', {x:133,y:100}, {}, {pts:['6a','6ab']});
      WG.addLink({pts:['6','6a'],junct:"switch"});
      WG.addLink({pts:['8','6b']});


      WG.addPoint('3a', {x:150,y:-50}, {}, {pts:['3','3a']});
      WG.addPoint('3b', {x:200,y:-50}, {}, {pts:['3a','3b']});
      WG.addLink({pts:['3b','4']});

      WG.addPoint('9', {x:0,y:-150}, {});
      WG.addPoint('10', {x:-100,y:-150}, {}, {pts:['9','10']});
      WG.addPoint('11a', {x:-150,y:-150}, {});
      WG.addPoint('11b', {x:-100,y:-100}, {});
      WG.addPoint('11aa', {x:-150,y:-200}, {}, {pts:['11a','11aa']});

      WG.addItem('plate','6ab',{'type':'plate','ontouch':{'addLink':{pts:['1','2','9'],junct:"switch"}}});
      WG.addItem('plate','9',{'type':'plate','ontouch':{'addLink':{pts:['10','11a','11b'],junct:"switch"}}});

      WG.addItem('pit','11aa',{'type':'pit','ontouch':{'damage':5}});


      WG.addPoint('12_line', {x:-100,y:-200}, {}, {pts:['12_line','11aa']});
      WG.addPoint('12a_line', {x:-50,y:-200}, {}, {pts:['12a_line','12_line']});
      WG.addPoint('12b_line', {x:0,y:-200}, {}, {pts:['12b_line','12a_line']});
      WG.addPoint('12c_line', {x:50,y:-200}, {}, {pts:['12c_line','12b_line']});


      var CA1 = CircleActor.alloc();
      GW.addActor(CA1,'act');
      var CA2 = CircleActor.alloc();
      GW.addActor(CA2,'act');

      WG.addObject('char',GW.gamePlayer,'1');
      WG.addObject('obj',CA1,'6');
      WG.addObject('obj',CA2,'12c_line');


      GAMEMODEL.gameSession.gamePlayer = GW.gamePlayer;
      var actlist = GW.gameActors;


          GAMEMUSIC.currSong=0;
          GAMEMUSIC.stopAudio();
          GAMEMUSIC.playAudio();

          GAMEMODEL.modelCamera.zoom = 1.0;
          GAMEMODEL.modelCamera.zoomIn();

};
