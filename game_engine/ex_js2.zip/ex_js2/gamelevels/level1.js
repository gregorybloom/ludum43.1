
LEVELLOADER.level1 = function()
{

      var GW = GameWorld.alloc();
      GAMEMODEL.gameSession.gameWorldList[0]=GW;
      GW.load();
      GW.size = {w:1200,h:1200};
      GW.updatePosition({x:(GW.size.w/2),y:(GW.size.h/2)});
  //    GW.updatePosition({x:0,y:0});

  /*
      var Tx0 = TextActor.alloc();
      Tx0.fontSize = 28;
      Tx0.text = "YOU ARE THE TRUCK";
      Tx0.updatePosition({x:550,y:50});
      this.gameSession.gameWorld.addActor(Tx0,'act');
  /**/

      var C = CharActor.alloc();
      C.updatePosition({x:200,y:250});
      GW.gamePlayer = C;
      GW.addActor(GW.gamePlayer,'player');
      GW.gamePlayer.parentWorld = GW;

      GAMEMODEL.modelCamera.target = C;
      GW.addActor(C,'act');



      var WG = WireGrid.alloc();
      WG.updatePosition({x:400,y:400});
      GW.addActor(WG,'act');
      WG.addPoint('1', {x:0,y:0});
      WG.addPoint('2', {x:0,y:100}, {}, {pts:['1','2']});
      WG.addPoint('3', {x:0,y:200}, {}, {pts:['2','3']});

      WG.addPoint('4', {x:0,y:300}, {}, {pts:['3','4']});
      WG.addPoint('5', {x:0,y:350}, {}, {pts:['4','5']});
      WG.addPoint('6', {x:0,y:400}, {}, {pts:['5','6']});
      WG.addPoint('7', {x:0,y:450}, {}, {pts:['6','7']});
      WG.addPoint('8', {x:0,y:500}, {}, {pts:['7','8']});
      WG.addPoint('9', {x:0,y:550}, {}, {pts:['8','9']});

      WG.addPoint('10', {x:0,y:600}, {});
      WG.addPoint('11', {x:0,y:650}, {}, {pts:['10','11']});
      WG.addPoint('12', {x:0,y:700}, {}, {pts:['11','12']});

      WG.addPoint('4ab', {x:-150,y:300}, {});
      WG.addPoint('4bb', {x:150,y:300}, {});
      WG.addPoint('6ab', {x:-150,y:400}, {}, {pts:['4ab','6ab']});
      WG.addPoint('6bb', {x:150,y:400}, {}, {pts:['4bb','6bb']});
      WG.addPoint('8ab', {x:-150,y:500}, {}, {pts:['6ab','8ab']});
      WG.addPoint('8bb', {x:150,y:500}, {}, {pts:['6bb','8bb']});

      WG.addPoint('4a', {x:-100,y:300}, {}, {pts:['4','4a']});
      WG.addPoint('4b', {x:100,y:300}, {}, {pts:['4','4b']});
      WG.addPoint('5a', {x:-100,y:350}, {}, {pts:['5','5a']});
      WG.addPoint('5b', {x:100,y:350}, {}, {pts:['5','5b']});
      WG.addPoint('6a', {x:-100,y:400}, {}, {pts:['6','6a']});
      WG.addPoint('6b', {x:100,y:400}, {}, {pts:['6','6b']});
      WG.addPoint('7a', {x:-100,y:450}, {}, {pts:['7','7a']});
      WG.addPoint('7b', {x:100,y:450}, {}, {pts:['7','7b']});
      WG.addPoint('8a', {x:-100,y:500}, {}, {pts:['8','8a']});
      WG.addPoint('8b', {x:100,y:500}, {}, {pts:['8','8b']});
      WG.addPoint('9a', {x:-100,y:550}, {}, {pts:['9','9a']});
      WG.addPoint('9b', {x:100,y:550}, {}, {pts:['9','9b']});

      WG.addLink({pts:['9a','8a','9']});
      WG.addLink({pts:['8a','7a','8']});
      WG.addLink({pts:['7a','6a','7']});
      WG.addLink({pts:['6a','5a','6']});
      WG.addLink({pts:['5a','4a','5']});
      WG.addLink({pts:['4a','4','4ab'],junct:"switch"});
      WG.addLink({pts:['8ab','8a'],junct:"switch"});

      WG.addLink({pts:['9b','8b','9']});
      WG.addLink({pts:['8b','7b','8']});
      WG.addLink({pts:['7b','6b','7']});
      WG.addLink({pts:['6b','5b','6']});
      WG.addLink({pts:['5b','4b','5']});
      WG.addLink({pts:['4b','4','4bb'],junct:"switch"});
      WG.addLink({pts:['8bb','8b'],junct:"switch"});

      WG.addLink({pts:['9','9a','9b'],junct:"switch"});

      WG.addItem('plate','6ab',{'type':'plate','ontouch':{'addLink':{pts:['9','10','9a','9b'],junct:"switch"}}});
      WG.addItem('plate','6bb',{'type':'plate','ontouch':{'addLink':{pts:['9','10','9a','9b'],junct:"switch"}}});

      WG.addItem('exit','12',{'type':'exit','ontouch':{'goToLevel':2}});
/*

      WG.addPoint('7', {x:200,y:150}, {}, {pts:['6','7'],type:"switch"});

      WG.addLink({pts:['6','6a'],type:"switch"});


      WG.addPoint('3a', {x:150,y:-50}, {}, {pts:['3','3a']});
      WG.addPoint('3b', {x:200,y:-50}, {}, {pts:['3a','3b']});
      WG.addLink({pts:['3b','4']});

      WG.addPoint('9', {x:0,y:-150}, {});
      WG.addPoint('10', {x:-100,y:-150}, {}, {pts:['9','10']});
      WG.addPoint('11a', {x:-150,y:-150}, {});
      WG.addPoint('11b', {x:-100,y:-100}, {});
      WG.addPoint('11aa', {x:-150,y:-200}, {}, {pts:['11a','11aa']});

      WG.addItem('plate','6ab',{'type':'plate','ontouch':{'addLink':{pts:['1','2','9'],type:"switch"}}});
      WG.addItem('plate','9',{'type':'plate','ontouch':{'addLink':{pts:['10','11a','11b'],type:"switch"}}});

      WG.addItem('pit','11aa',{'type':'pit','ontouch':{'damage':5}});


      WG.addPoint('12_line', {x:-100,y:-200}, {}, {pts:['12_line','11aa']});
      WG.addPoint('12a_line', {x:-50,y:-200}, {}, {pts:['12a_line','12_line']});
      WG.addPoint('12b_line', {x:0,y:-200}, {}, {pts:['12b_line','12a_line']});
      WG.addPoint('12c_line', {x:50,y:-200}, {}, {pts:['12c_line','12b_line']});


      var CA1 = CircleActor.alloc();
      GW.addActor(CA1,'act');
      var CA2 = CircleActor.alloc();
      GW.addActor(CA2,'act');

      WG.addObject('obj',CA1,'6');
      WG.addObject('obj',CA2,'12c_line');
/**/
      WG.addObject('char',GW.gamePlayer,'1');


      GAMEMODEL.gameSession.gamePlayer = GW.gamePlayer;
      var actlist = GW.gameActors;


          GAMEMUSIC.currSong=0;
          GAMEMUSIC.stopAudio();
          GAMEMUSIC.playAudio();

          GAMEMODEL.modelCamera.zoom = 1.0;
          GAMEMODEL.modelCamera.zoomIn();

};
