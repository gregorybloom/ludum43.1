
LEVELLOADER.level2 = function()
{
        var GW = GameWorld.alloc();
        GAMEMODEL.gameSession.gameWorldList[0]=GW;
        GW.load();
        GW.size = {w:1200,h:1200};
        GW.updatePosition({x:(GW.size.w/2),y:(GW.size.h/2)});
    //    GW.updatePosition({x:0,y:0});

    /*
        var Tx0 = TextActor.alloc();
        Tx0.fontSize = 28;
        Tx0.text = "YOU ARE THE TRUCK";
        Tx0.updatePosition({x:550,y:50});
        this.gameSession.gameWorld.addActor(Tx0,'act');
    /**/

        var C = CharActor.alloc();
        C.updatePosition({x:200,y:250});
        GW.gamePlayer = C;
        GW.addActor(GW.gamePlayer,'player');
        GW.gamePlayer.parentWorld = GW;

        GAMEMODEL.modelCamera.target = C;
        GW.addActor(C,'act');



        var WG = WireGrid.alloc();
        WG.updatePosition({x:400,y:400});
        GW.addActor(WG,'act');
        WG.addPoint('1', {x:0,y:0});
        WG.addPoint('2', {x:0,y:100}, {}, {pts:['1','2']});
        WG.addPoint('3', {x:0,y:200}, {}, {pts:['2','3']});

        WG.addPoint('4', {x:100,y:200}, {}, {pts:['3','4']});
        WG.addPoint('5', {x:150,y:200}, {}, {pts:['4','5']});
        WG.addPoint('6', {x:200,y:200}, {}, {pts:['5','6']});
        WG.addPoint('7', {x:250,y:200}, {}, {pts:['6','7']});
        WG.addPoint('8', {x:300,y:200}, {}, {pts:['7','8']});
        WG.addPoint('9', {x:350,y:200}, {}, {pts:['8','9'],jump:1});

        WG.addPoint('10', {x:400,y:200}, {}, {pts:['9','10']});
        WG.addPoint('11', {x:450,y:200}, {}, {pts:['10','11'],jump:1});

        WG.addPoint('12', {x:500,y:200}, {}, {pts:['11','12']});

        WG.addPoint('13', {x:550,y:200}, {}, {pts:['12','13'],jump:1});


        WG.addPoint('13a', {x:550,y:300}, {}, {pts:['13a','13']});
        WG.addItem('plate','13',{'type':'plate','ontouch':{'addLink':{pts:['12t','13b']}}});
        WG.addPoint('13b', {x:550,y:350}, {}, {pts:['13b','13a']});


        WG.addPoint('5a', {x:0,y:300}, {});
        WG.addPoint('6a', {x:100,y:300}, {}, {pts:['5a','6a']});
        WG.addPoint('7a', {x:200,y:300}, {}, {pts:['6a','7a']});
        WG.addPoint('8a', {x:250,y:300}, {}, {pts:['7a','8a']});
        WG.addPoint('9a', {x:300,y:300}, {}, {pts:['8a','9a']});

        WG.addPoint('5b', {x:0,y:350}, {});
        WG.addPoint('6b', {x:100,y:350}, {}, {pts:['5b','6b']});
        WG.addPoint('7b', {x:200,y:350}, {}, {pts:['6b','7b']});
        WG.addPoint('8b', {x:250,y:350}, {}, {pts:['7b','8b']});
        WG.addPoint('9b', {x:300,y:350}, {}, {pts:['8b','9b']});

        WG.addLink({pts:['9a','9b']});
        var CA2 = CircleActor.alloc();
        CA2.enemyType = 1;
        CA2.startDelay+=2;
        CA2.radius-=6;
        GW.addActor(CA2,'act');
        WG.addObject('obj',CA2,'5a');
        var CA3 = CircleActor.alloc();
        CA3.startDelay+=3;
        GW.addActor(CA3,'act');
        WG.addObject('obj',CA3,'5b');

        WG.addPoint('10t', {x:400,y:350}, {}, {pts:['9b','10t']});
        WG.addPoint('11t', {x:450,y:350}, {}, {pts:['10t','11t']});
        WG.addPoint('12t', {x:500,y:350}, {}, {pts:['11t','12t']});
        WG.addLink({pts:['12t','13b'],jump:1});

        for(i=14;i<65;i++) {
          var px = 600+33*(i-14);
          var m = (i-1)+'';
          var n = i+'';
          WG.addPoint( n, {x:px,y:200}, {}, {pts:[ m,n ]});

          var k = i%8;
          var yx = 150 + 100*Math.floor(k/5);
          if(k == 2 || k == 6) {
            if(i<40)    WG.addPoint( n+'o', {x:px,y:yx}, {}, {pts:[ n,n+'o'],jump:1});
            if(i>=40)    WG.addPoint( n+'o', {x:px,y:yx}, {}, {pts:[ n,n+'o'],junct:'switch','nodefault':1});
          }
          if(k == 3 || k == 7) {
            WG.addPoint( n+'o', {x:px,y:yx}, {}, {pts:[ m+'o',n+'o']});
            WG.addLink( {pts:[ n+'o',n],jump:1});
          }

        }


        var ARR=[32,64];
        for(a=0; a<2; a++) {
          var tt = ARR[a]+'';
          WG.addPoint(tt+'t', {x:(600 + (ARR[a]-14)*33),y:350}, {}, {pts:[tt+'t',tt]});
          var CA2 = CircleActor.alloc();
          CA2.enemyType = 1;
          CA2.startDelay = 0;
          CA2.curBehavior='walk';
          CA2.behaviors['walk']=[];
          CA2.radius-=6;
          var xt = 12;
          if(a==1)  xt = 32;
          for(i=ARR[a];i>=xt;i--)  CA2.behaviors['walk'].push({type:'nextTo',to:(''+i)});
          CA2.behaviors['walk'].push({type:'nextTo',to:xt+'t'});
          CA2.behaviors['walk'].push({type:'nextTo',to:tt+'t'});
          var xx = '16';
          if(a==1)  xx = '40';
          WG.addItem('plate',xx,{'type':'plate','ontouch':{'addObject':{'obj':CA2,'to':tt+'t'}}});
        }


        var CA2 = CircleActor.alloc();
        CA2.enemyType = 1;
        CA2.startDelay+=2;
        CA2.radius-=6;
        CA2.curBehavior='walk';
        CA2.behaviors['walk']=[];
        CA2.behaviors['walk'].push({type:'nextTo',to:'32'});
        CA2.behaviors['walk'].push({type:'done'});
        WG.addItem('plate','35',{'type':'plate','ontouch':{'addObject':{'obj':CA2,'to':'32t'}}});



        WG.addPoint( '65', {x:2300,y:200}, {}, {pts:[ '64','65' ]});
        WG.addPoint( '65a', {x:2300,y:250}, {}, {pts:[ '65','65a' ]});
        WG.addPoint( '65b', {x:2300,y:300}, {}, {pts:[ '65a','65b' ]});

        WG.addPoint( '66', {x:2400,y:200}, {}, {pts:[ '65','66' ],jump:1});
        WG.addPoint( '66a', {x:2400,y:250}, {}, {pts:[ '65a','66a' ],jump:1});
        WG.addLink({pts:['66a','66']});

        WG.addPoint( '67', {x:2500,y:200}, {}, {pts:[ '66','67' ]});
        for(i=68;i<71;i++) {
          var px = 2550+50*(i-68);
          var m = (i-1)+'';
          var n = i+'';
          WG.addPoint( n, {x:px,y:200}, {}, {pts:[ m,n ]});
        }



        for(i=71;i<88;i++) {
          var px = 2700 +50*(i-71);
          var m = (i-1)+'';
          var n = i+'';
          WG.addPoint( n, {x:px,y:200}, {}, {pts:[ m,n ]});

          var k = i%8;
//          var yx = 150 + 100*Math.floor(k/5);
          if(k == 0)      WG.addPoint( n+'o', {x:px,y:250}, {}, {pts:[ n+'o',n],jump:1});
          if(k == 1)      WG.addPoint( n+'o', {x:px,y:250}, {}, {pts:[ n+'o',m+'o']});
          if(k == 1)      WG.addLink( {pts:[ n,n+'o'],jump:1});

          if(k >= 3 && k <= 4)      WG.addLink( {pts:[ m,n],jump:1});
          if(k == 2)      WG.addPoint( n+'b', {x:px,y:150}, {}, {pts:[ n,n+'b'],nodefault:1});
          if(k == 2)      WG.addPoint( n+'a', {x:px,y:250}, {}, {pts:[ n+'a',n]});
          if(k == 3)      WG.addPoint( n+'b', {x:px,y:150}, {}, {pts:[ n+'b',n]});
          if(k == 3)      WG.addPoint( n+'a', {x:px,y:250}, {}, {pts:[ n,n+'a'],nodefault:1});
          if(k == 3)      WG.addLink( {pts:[m+'b',n+'b']});
          if(k == 3)      WG.addLink( {pts:[n+'a',m+'a']});

          if(k == 3) {
            for(x=0; x<2; x++) {
              var CA2 = CircleActor.alloc();
              CA2.enemyType = 1;
              CA2.radius-=6;
              CA2.startDelay=1;
              CA2.curBehavior='walk';
              CA2.behaviors['walk']=[];
              if(x==0) {
                CA2.behaviors['walk'].push({type:'nextTo',to:m+'a'});
                CA2.behaviors['walk'].push({type:'nextTo',to:m});
                CA2.behaviors['walk'].push({type:'nextTo',to:m+'b'});
              }
              CA2.behaviors['walk'].push({type:'nextTo',to:n+'b'});
              CA2.behaviors['walk'].push({type:'nextTo',to:n});
              CA2.behaviors['walk'].push({type:'nextTo',to:n+'a'});   /**/
              if(x==1) {
                CA2.behaviors['walk'].push({type:'nextTo',to:m+'a'});
                CA2.behaviors['walk'].push({type:'nextTo',to:m});
                CA2.behaviors['walk'].push({type:'nextTo',to:m+'b'});
              }
              if(x==0)               WG.addObject('obj',CA2,n+'a');
              if(x==1)               WG.addObject('obj',CA2,m+'b');
              GW.addActor(CA2,'act');
            }
          }
          WG.addPoint( '66', {x:2400,y:200}, {}, {pts:[ '65','66' ],jump:1});

//          WG.addPoint( n+'o', {x:px,y:200}, {}, {pts:[ n,n+'o'],junct:'switch','nodefault':1});
/*          }
          if(k == 3 || k == 7) {
            WG.addPoint( n+'o', {x:px,y:yx}, {}, {pts:[ m+'o',n+'o']});
            WG.addLink( {pts:[ n+'o',n],jump:1});
          }   /**/

        }

        WG.addPoint( '88', {x:3600,y:200}, {}, {pts:[ '87','88' ],jump:1});
        WG.addPoint( '89', {x:3600,y:250}, {}, {pts:[ '88','89' ],jump:1});
        WG.addPoint( '90', {x:3600,y:300}, {}, {pts:[ '89','90' ],jump:1});
        WG.addPoint( '91', {x:3600,y:350}, {}, {pts:[ '90','91' ],jump:1});
        WG.addPoint( '92', {x:3600,y:400}, {}, {pts:[ '91','92' ],jump:1});
        WG.addPoint( '93', {x:3600,y:450}, {}, {pts:[ '92','93' ],jump:1});
        WG.addPoint( '94', {x:3600,y:500}, {}, {pts:[ '93','94' ],jump:1});
        for(i=95;i<=110;i++) {
          var px = 3600 - 50*(i-94);
          var n = i+'';
          var m = (i-1)+'';
          WG.addPoint( n, {x:px,y:500}, {}, {pts:[ m,n ],jump:1});
        }


        WG.addObject('char',GW.gamePlayer,'1');

        WG.addItem('exit','110',{'type':'exit','ontouch':{'goToLevel':'open'}});

  /*
        WG.addLink({pts:['9a','8a','9']});
        WG.addLink({pts:['8a','7a','8']});
        WG.addLink({pts:['7a','6a','7']});
        WG.addLink({pts:['6a','5a','6']});
        WG.addLink({pts:['5a','4a','5']});
        WG.addLink({pts:['4a','4','4ab'],type:"switch"});
        WG.addLink({pts:['8ab','8a'],type:"switch"});

        WG.addLink({pts:['9b','8b','9']});
        WG.addLink({pts:['8b','7b','8']});
        WG.addLink({pts:['7b','6b','7']});
        WG.addLink({pts:['6b','5b','6']});
        WG.addLink({pts:['5b','4b','5']});
        WG.addLink({pts:['4b','4','4bb'],type:"switch"});
        WG.addLink({pts:['8bb','8b'],type:"switch"});

        WG.addLink({pts:['9','9a','9b'],type:"switch"});

        WG.addItem('plate','6ab',{'type':'plate','ontouch':{'addLink':{pts:['9','10','9a','9b'],type:"switch"}}});
        WG.addItem('plate','6bb',{'type':'plate','ontouch':{'addLink':{pts:['9','10','9a','9b'],type:"switch"}}});

  /*

        WG.addPoint('7', {x:200,y:150}, {}, {pts:['6','7'],type:"switch"});

        WG.addLink({pts:['6','6a'],type:"switch"});


        WG.addPoint('3a', {x:150,y:-50}, {}, {pts:['3','3a']});
        WG.addPoint('3b', {x:200,y:-50}, {}, {pts:['3a','3b']});
        WG.addLink({pts:['3b','4']});

        WG.addPoint('9', {x:0,y:-150}, {});
        WG.addPoint('10', {x:-100,y:-150}, {}, {pts:['9','10']});
        WG.addPoint('11a', {x:-150,y:-150}, {});
        WG.addPoint('11b', {x:-100,y:-100}, {});
        WG.addPoint('11aa', {x:-150,y:-200}, {}, {pts:['11a','11aa']});

        WG.addItem('plate','6ab',{'type':'plate','ontouch':{'addLink':{pts:['1','2','9'],type:"switch"}}});
        WG.addItem('plate','9',{'type':'plate','ontouch':{'addLink':{pts:['10','11a','11b'],type:"switch"}}});

        WG.addItem('pit','11aa',{'type':'pit','ontouch':{'damage':5}});


        WG.addPoint('12_line', {x:-100,y:-200}, {}, {pts:['12_line','11aa']});
        WG.addPoint('12a_line', {x:-50,y:-200}, {}, {pts:['12a_line','12_line']});
        WG.addPoint('12b_line', {x:0,y:-200}, {}, {pts:['12b_line','12a_line']});
        WG.addPoint('12c_line', {x:50,y:-200}, {}, {pts:['12c_line','12b_line']});


        var CA2 = CircleActor.alloc();
        GW.addActor(CA2,'act');

        WG.addObject('obj',CA2,'12c_line');
  /**/


        GAMEMODEL.gameSession.gamePlayer = GW.gamePlayer;
        var actlist = GW.gameActors;

        GW.size = {w:2200,h:2200};
        GW.updatePosition({x:(GW.size.w/2),y:(GW.size.h/2)});

            GAMEMUSIC.currSong=0;
            GAMEMUSIC.stopAudio();
            GAMEMUSIC.playAudio();

            GAMEMODEL.modelCamera.zoom = 1.0;
            GAMEMODEL.modelCamera.zoomIn();
};
