
LEVELLOADER={
};

LEVELLOADER.init = function()
{
};


LEVELLOADER.loadLevel = function(num)
{
    GAMEMODEL.currentLevel = num;
    if(num == 0)        LEVELLOADER.level0();
    if(num == 1)        LEVELLOADER.level1();
    if(num == 2)        LEVELLOADER.level2();


    if(num == "open")    LEVELLOADER.levelOpen();
    if(num == "build")    LEVELLOADER.levelbuild();

    if(num == "test")    LEVELLOADER.leveltest();
};
